//
// POGO VISION
// Copyright (C) 2004 by the Institute for Systems Biology, Dave Orendorff. 
// All rights reserved.
// This code is distributed under the terms of the GNU Library General Public License.
// See COPYING for details.
//
// SPOTAREA.CPP
// Actual code that tries to figure out the exact spot demensions based
// off of preliminary assessment. 
//
// There are actually to solutions here, the second is not implemented.
//	1. Look at the 2nd derivitive and fill in the negative pool of pixels inside of the spot
//	2. Trace around the 2nd derivitive spot by looking for a continouous ring of very different pixels
//



#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#include "spotarea.h"
#include "auxiliary.h"
#include "image.h"
#include "processimage.h"


#define FILL_VALUE 120
#define GHOST_VALUE 3

static Image* s_binaryImg = NULL;


int recursiveFill(FltImage* source, Image* binaryOut, int x, int y, float threshold, int coefficient);
int fillInTheRing(FltImage* theVignette, int theXCord, int theYCord, int theRadius);
int outlineSpotPositive(FltImage* theVignette, int theXCord, int theYCord, int theRadius);
int makeShadow(Image* binary);


/**
	Returns the area of the spot. It returns 0 or a large number if it can not use 
	the given spot. 
	Unit of length is the pixel. 

  Game Plan:
	1. Take the negative laplacian of a spots image. This image should have a 
		a ring around the center of negative values.
	2. Fill in this ring using a threshold of 0. Put the filled pixels on a new, binary image.
	3. Fill in this binary image shape using pixel dialation. 
	4. Return the sum of steps 2 and 3. 
  */

Image* makeScreen(FltImage* theVignette){
	Image* screen = newImage(theVignette->_width, 
		theVignette->_height, (unsigned char *)calloc(theVignette->_height * theVignette->_width, sizeof(char)));
	return screen;
}

// theXCord and theYCord are from the top left. 
int spotArea(FltImage* theVignette, int theXCord, int theYCord, int theRadius){
	assert(theVignette != NULL);

	// set up static binary image
	if (s_binaryImg == NULL)
		s_binaryImg = makeScreen(theVignette);
	else if (s_binaryImg->_height != s_binaryImg->_height || 
		s_binaryImg->_width != s_binaryImg->_width){
		// the image is not the correct size
		deleteImage(s_binaryImg);
		s_binaryImg = makeScreen(theVignette);
	} else{
		// just clear the data
		for (int i = 0; i < s_binaryImg->_height*s_binaryImg->_width; i++)
			s_binaryImg->_data[i] = 0;
	}

	// okay, we have our screen set up, lets do it...
	// use 1st algorthm
	return fillInTheRing(theVignette, theXCord, theYCord, theRadius);
}



/**
	This is the function that executes the gameplan mentioned above.

	Pre: 
		theVignette != null; theXCord, theYCord and theRadius are valid and semi-accurate; 
		s_binaryImg != null && sizeof(s_binaryImg) == sizeof(theVignette)
	Post: 
		theVignette is unchanged. The return value is the number of pixels inside of 
		the bright ring of the spot; 0 is returned if there is a leak or there is not
		a large area of negative pixels within the domain of the spot. 
		Shouldn't be a problem if the image had a Gaussian filter applied to it. 

*/
int fillInTheRing(FltImage* theVignette, int theXCord, int theYCord, int theRadius){

	// the maximum pixel value proposed pixel ring
	float cutOff = 0;

	int offset = 0;	// there's a chance that the very center is bright
	int minArea = theRadius * 5;
	int area = 0;


	// try to find the laplacian ring
	for (; offset <= theRadius && area < minArea; offset++){
		// keep guesing pixels until we find one that is connected to the negative ring
		int pixelsFilled = recursiveFill(theVignette, s_binaryImg, theXCord + (offset %2)*offset, theYCord + offset, cutOff, 1);
		area += pixelsFilled;
	}

	// probably had a leak if (area > totalArea - spotArea(guessed) + epsilon)
	if (area > (s_binaryImg->_height * s_binaryImg->_width - theRadius * theRadius * 3))
		return 0;
	
	// now just fill in the shape
	area += makeShadow(s_binaryImg);

	return area;
}

/**
	In the binary image, whenever there are two filled in pixels on the same row/collumn. 
	Any pixels between them	will be filled in also. The total number of pixels that were 
	filled in is the return value. 

	binary: binary consists of pixels that are either 0 or FILL_VALUE
	Time: O(n)
	pre: binary is an initialized Image
	post: changes binary and returns the number of pixels that were filled in. 

    Algorthm: scan each row/col. 
		defs: X = filled, 0 = not filled
		pre: 00X00X0X00
		post:00XXXXXX00
*/
int makeShadow(Image* binary){
	assert(binary != NULL);
	int pixelsChanged = 0;

	// fill in the rows
	for (int y = 0; y < binary->_height; y++)
	{
		int x1 = 0;
		int x2 = binary->_width - 1;	// these are indecies .:. -1

		for (; x1 < binary->_width; x1++){
			if (getPixel(binary, x1, y) == FILL_VALUE)
				break;
		}

		for (; x2 > 0; x2--){
			if( getPixel(binary, x2, y) == FILL_VALUE)
				break;
		}

		// fill in the line
		while (x1 < x2){
			if (getPixel(binary, x1, y) == 0){
				setPixel(binary, x1, y, FILL_VALUE);
				pixelsChanged++;
			}
			x1++;
		}
	}

	// now the same thing, just fill in the collums
	for (int x = 0; x < binary->_width; x++)
	{
		int y1 = 0;
		int y2 = binary->_height - 1;

		for (; y1 < binary->_height; y1++){
			if (getPixel(binary, x, y1) == FILL_VALUE)
				break;
		}

		for (; y2 > 0; y2--){
			if( getPixel(binary, x, y2) == FILL_VALUE)
				break;
		}

		// fill in the line
		while (y1 < y2){
			if (getPixel(binary, x, y1) == 0){
				setPixel(binary, x, y1, FILL_VALUE);
				pixelsChanged++;
			}
			y1++;
		}
	}

	return pixelsChanged;
}

/** 
	Fill onto the binaryOut without crossing any pixels that are too different. 
	Diaganals don't count.
	coefficient is 1 or -1: 1 indicates the shape outline is bright, -1 is a dark shape outline.
	Calls in the NEWS directions, tail recursive. 

    Pre: parameters initialized; sizeof(source) == sizeof(binaryout); coefficient is -1 or 1. 
	Post: number of pixels filled; binaryOut is changed to reflect filled pixels
*/
int recursiveFill(FltImage* source, Image* binaryOut, int x, int y, float threshold, int coefficient){
	assert(coefficient == 1 || coefficient == -1);

	// out of bounds?
	if (!inBounds(binaryOut, x, y)) return 0;	

	// did we reach a border (edge of screen or edge of shape)? Or, did we already draw here?
	if (coefficient*getFltPixel(source, x, y) >= coefficient*threshold || getPixel(binaryOut, x, y))
		return 0; 

	setPixel(binaryOut, x, y, FILL_VALUE);

	// call away: let the friends know that they too can be filled.  
	return 1 + recursiveFill(source, binaryOut, x + 1, y, threshold, coefficient)+ 
		recursiveFill(source, binaryOut, x - 1, y, threshold, coefficient) + 
		recursiveFill(source, binaryOut, x, y + 1, threshold, coefficient) +
		recursiveFill(source, binaryOut, x, y - 1, threshold, coefficient);
}



////////////////////////////////////////////////////////
/////////////////////////////////////////////// NOT USED
int outlineSpot(FltImage* theVignette, int theXCord, int theYCord, int theRadius);
int fillInTheRing2(FltImage* theVignette, int theXCord, int theYCord, int theRadius);


/** 
	If a pixels is by 3+ friends that are filled in then itself is filled in. 
	A friend of a pixel is a pixel in the NEWS directions (a max of 4 friends). 

  Time: O(n) usually; hypothetically O(nLog(n)) possible but VERY unlikely. 
  Pre: image != NULL; x, y contained in image; 1 < radius
  Post: returns the number of pixels that could be dialated. It tries to be sneaky 
	by looking only at pixels that are near the spots center, a rad distance away. 

  notes:
	doesn't consider pixels on the edges
	this could be optimized
	assumes a pixels value in image is FILL_VALUE or 0
*/
int dialatePixels(Image* image, int xPos, int yPos, int radius){

	int numchanged = 0;
	// radius = MIN(radius, 4);
	// look at a square the size of 2x2 radii
	// and just look at pixels that are potentials

	int startX = MAX( xPos - radius, 0+1);
	int startY = MAX( yPos - radius, 0+1);
	int maxX = MIN(xPos + radius, image->_width-2);
	int maxY = MIN(yPos + radius, image->_height-2);

  for ( yPos = startX; yPos < maxY; yPos++)
    for ( xPos = startY; xPos < maxX; xPos++)	
      {

		// a blank pixel!
		if (getPixel(image, xPos, yPos) == 0){
			int neiborSum = getPixel(image, xPos+1, yPos) + getPixel(image, xPos-1, yPos) + 
				getPixel(image, xPos, yPos+1) + getPixel(image, xPos, yPos-1);
			if (neiborSum >= 3*FILL_VALUE){	// by enough neibors?
				setPixel(image, xPos, yPos, FILL_VALUE);
				// backtrack, in case this pixels friends can change now, due to this change
				xPos = MAX(xPos - 1, startX);
				yPos = MAX(yPos - 1, startY);

				numchanged++;
			}
		}

      }

	return numchanged;
}




///////////////////////////////////////////////////////
/////////////////////////////////////////// ALGORITHM 2

/**
	Game plan:

		Using Negative Laplacian
		Line pointing full right is 0, strait up is PI/2...
		While we are not on a filled in pixel AND there is a NextPixel to fill...
			Start with the outmost negative pixel at 0
			Search for the next negative pixel based on our current quadrant (see *)
			IF we find a pixel 
				THEN set it as NextPixel, mark it's location on it the shadowImage
			IF no pixel found
				THEN move to the next logical point based on location
				using Bresenhem's midpoint circle algorithm

  * Each quadrant should cover scans of up to PI / 2. The range starts at the tangent line 
	at the begining of the quadrant and ends at the tangent line at the end of the quadrant.
	This implies that 3 different pixels relative to the current will be scanned for each quadrant.

  *	Quadrant are numbered, starting at 0 and increase in the counterclockwise direction.

*/

// sets <x, y> to a pixel that is on the outside of the border (defined by the (-) laplacian ring)
// with ~95% certainty.
// cX, cY specify the approximate center. radius is also an approximation 
void borderPixel(FltImage *image, int cX, int cY, int &x, int &y, int radius){
	y = cY;
	x = cX + 2;//MAX(radius, 5);
	// want to find the most negative pixel
	int length = image->_height * image->_width;
	float min = 999;
	int minIndex = 0; 
	for (int i = 0; i < length; i++){
		if (image->_data[i] < min){
			min = image->_data[i];
			minIndex = i;
		}
	}
	
	x = minIndex % image->_width;
	y = minIndex / image->_width;
//	while (getFltPixel(image, --x, y) > 0);
//	while (inBoundsFlt(image, --x, y) && getFltPixel(image, x, y) < 0);

}




/* another area spotter
// traverse counterclockwise around the rim of the spot
// note: the circle and quadrant in relation to a pixel are NOT the same.

	spot:		|					pixel neibors:	0 * 3
			   1|0									* C *
			---------								1 * 2 
			   2|3
			    |											- C is THE pixel.


*/
int fillInTheRing2(FltImage* theVignette, int theXCord, int theYCord, int theRadius){
	assert(theVignette != NULL);

	// temporary x, y variables that indicate where we are along the circle
	int x, y;
	borderPixel(theVignette, theXCord, theYCord, x, y, theRadius);

	int filled = outlineSpot(theVignette, theXCord, theYCord, theRadius);
	
	filled += makeShadow(s_binaryImg);
	
	return filled;
	
}



// neighbors size is 6 ints 
void neighbor(int &x, int &y, char direction){

	if (direction < 3)
		y--;
	else if (direction == 3 || direction == 7)
		y = y;
	else
		y++;

	if (direction > 1 && direction < 5)
		x--; 
	else if (direction == 1 || direction == 5)
		x = x;
	else
		x++;
}

// returns an image with pixels in the negative range burned onto it
Image* iceBurn(FltImage* alpha){
	Image *beta = newImage(alpha->_width, alpha->_height, new unsigned char[alpha->_width* alpha->_height]);
	int length = beta->_width * beta->_height;
	for (int i = 0; i < length; i++)
//		alpha->_data[i] > 0 ? beta->_data[i] = FILL_VALUE : beta->_data[i] = 0;
		alpha->_data[i] < -45 ? beta->_data[i] = FILL_VALUE : beta->_data[i] = 0;
	return beta;
}

/*
		2  1  0
		3  *  7
		4  5  6

pre: binary image is the same size as theVignette
post: outline a negative ring

*/
int outlineSpot(FltImage* theVignette, int theXCord, int theYCord, int theRadius){
	assert(theVignette != NULL);
	int filled = 0;
//	showFltImage(theVignette);

	// note: leaks
//	showImage(iceBurn(theVignette));

	// temporary x, y variables that indicate where we are along the circle
	int x, y;
	borderPixel(theVignette, theXCord, theYCord, x, y, theRadius);

	int tx = x; int ty = y;	// temporary variables 
	float temp1, temp2, temp3;

	// see what direction we need to move
	char direction = 0;
	temp1 = 999;
	for (int d = 0; d < 8; d++){
		tx = x; ty = y;
		neighbor(tx, ty, d);
		if (inBounds(s_binaryImg, tx, ty) && getFltPixel(theVignette, tx, ty) < temp1){
			direction = d;
			temp1 = getFltPixel(theVignette, tx, ty);
		}
	}

	// direction is now the way to go around the circle

	// scan within 3
	while (inBounds(s_binaryImg, x, y) && getPixel(s_binaryImg, x, y) == 0){
		setPixel(s_binaryImg, x, y, FILL_VALUE);
//		showImage(s_binaryImg);

		int tx = x; int ty = y;
		neighbor(tx, ty,  (direction + 7) % 8);
		inBounds(s_binaryImg, tx, ty) ? temp1 = getFltPixel(theVignette, tx, ty) : temp1 = 999;

		tx = x; ty = y;
		neighbor(tx, ty,  (direction + 1) % 8);
		inBounds(s_binaryImg, tx, ty) ? temp2 = getFltPixel(theVignette, tx, ty) : temp2 = 999;

		tx = x; ty = y;
		neighbor(tx, ty,  direction);
		inBounds(s_binaryImg, tx, ty) ? temp3 = getFltPixel(theVignette, tx, ty) : temp3 = 999;

		float min = MIN(temp1, temp2);
		if ( min > temp3){
			// continue in same direction
			x = tx; y = ty;
		}else if (temp1 < temp2){
			direction = (direction + 7) % 8;
			neighbor(x, y,  direction);
		}
		else{
			if(temp2 == 999) return 0;;
			direction = (direction + 1) % 8;
			neighbor(x, y, direction);
		}

/*		if (getFltPixel(theVignette, x, y) >= 0) // didn't find one!
		{
			assert(false);// panic
		}*/
		filled++;
	
	}
//	showImage(s_binaryImg);

	return filled;
}

/*
		2  1  0
		3  *  7
		4  5  6

pre: binary image is the same size as theVignette
outline a positive ring

*/
int outlineSpotPositive(FltImage* theVignette, int theXCord, int theYCord, int theRadius){
	assert(theVignette != NULL);
	int filled = 0;
//	showFltImage(theVignette);

	// note: leaks
//	showImage(iceBurn(theVignette));

	// temporary x, y variables that indicate where we are along the circle
	int x, y;
	borderPixel(theVignette, theXCord, theYCord, x, y, theRadius);

	char direction = 1; 
	// scan within 3
	while (inBounds(s_binaryImg, x, y) && getPixel(s_binaryImg, x, y) == 0){
		setPixel(s_binaryImg, x, y, FILL_VALUE);

//		showImage(s_binaryImg);

		// get the most positive neighbor 
		float temp1, temp2, temp3;

		int tx = x; int ty = y;
		neighbor(tx, ty,  (direction + 7) % 8);
		inBounds(s_binaryImg, tx, ty) ? temp1 = getFltPixel(theVignette, tx, ty) : temp1 = -999;

		tx = x; ty = y;
		neighbor(tx, ty,  (direction + 1) % 8);
		inBounds(s_binaryImg, tx, ty) ? temp2 = getFltPixel(theVignette, tx, ty) : temp2 = -999;

		tx = x; ty = y;
		neighbor(tx, ty,  direction);
		inBounds(s_binaryImg, tx, ty) ? temp3 = getFltPixel(theVignette, tx, ty) : temp3 = -999;

		float max = MAX(temp1, temp2);
		if ( max < temp3){
			// continue in same direction
			x = tx; y = ty;
		}else if (temp1 > temp2){
			direction = (direction + 7) % 8;
			neighbor(x, y,  direction);
		}
		else{
			if(temp2 == -999) return 0;
			direction = (direction + 1) % 8;
			neighbor(x, y, direction);
		}

/*		if (getFltPixel(theVignette, x, y) >= 0) // didn't find one!
		{
			assert(false);// panic
		}*/
		filled++;
	
	}
//	showImage(s_binaryImg);

	return filled;
}