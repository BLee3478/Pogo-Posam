//
// POGO VISION
// Copyright (C) 2004 by the Institute for Systems Biology, Dave Orendorff. 
// All rights reserved.
// This code is distributed under the terms of the GNU Library General Public License.
// See COPYING for details.
//
// GRID.CPP
// Basic functions dealing with accessing the Image's geometry. 
// There is an unregulated rule stating that a Grid's data should 
// not be modified outside of these functions. 
// 

#include <stdio.h>
#include <assert.h>


#include "grid.h"
#include "globals.h"
#include "auxiliary.h"


double s_dX = -1;
double s_dY = -1;


// makes new Grid, always call this function
// pre: (nRows > 0 && nCols > 0), top < bottom, left > right
// post: creates new grid with specified parameters. 
Grid* newGrid(int top, int left, int bottom, int right, int nRows, int nCols){
	Grid* grid = new Grid;

	grid->_top = top; grid->_left = left; 
	grid->_bottom = bottom; grid->_right = right; 

	grid->_cols = nCols; grid->_rows = nRows; 

	s_dX = (double)(grid->_right - grid->_left) / (double)grid->_cols;
	s_dY = (double)(grid->_bottom - grid->_top) / (double)grid->_rows;
	

	grid->_dx = roundDbl(s_dX);
	grid->_dy = roundDbl(s_dY);

	return grid;
}

/* 
	Returns the top left pixel of specified vignette into (x, y)
	This function actually needs to be a little tricky because _dx and
		_dy are not good enough; 

	pre: grid is initiallized; row, col > 0 AND inside(grid)
	post: (x, y) is top left pixels of this vignette, returns (-1, -1) if
		vignette not found. 

*/
void getVignette(Grid* grid, int row, int col, int &x, int &y){
	assert (grid != 0);

	// make sure we asking for a legitement location
	if (row < 0 || col < 0 || row > grid->_rows || col > grid->_cols){
		x = -1;
		y = -1;
		return;
	}

	x = roundDbl(col * s_dX) + grid->_left;
	y = roundDbl(row * s_dY) + grid->_top; 
}
