//
// POGO VISION
// Copyright (C) 2004 by the Institute for Systems Biology, Dave Orendorff. 
// All rights reserved.
// This code is distributed under the terms of the GNU Library General Public License.
// See COPYING for details.
//
// FFT.H
// Origionally from DAPPLE
// Interface to the FFT library
//
// See fft.cpp for details on calling semantics.

#ifndef __FFT_H
#define __FFT_H

#include <fftw3.h>
#include <stdlib.h>

// Accessors for FFTW complex type -- we undef these before the
// end of the header.
#define c_re(x) ((x)[0])
#define c_im(x) ((x)[1])

class FFT {
public:
  typedef fftw_complex Complex;      // FFT library's complex type
  
  FFT(int fftWidth, int fftHeight);
  ~FFT();
  
  // FFT size
  int width()  const { return fftWidth;  }
  int height() const { return fftHeight; }
  
  // Output size of a real-to-complex 2D FFT on a width x height input
  // (less than the input size due to symmetry!).
  //
  // Callers will allocate a Complex array of this size to receive the 
  // output of fft2() and serve as the input to ifft2_extract().
  //
  int transformSize() const { return (fftWidth / 2 + 1) * fftHeight; }
  
  // 2D forward transform
  void fft2(const float *dataIn, Complex *dataOut,
	    int dataWidth, int dataHeight);
  
  // 2D reverse transform, extracting only part of the result
  void ifft2_extract(Complex *dataIn, float *dataOut,
		     int dataWidth, int dataHeight,
		     int maskWidth, int maskHeight);
  
  
  // Pointwise-multiply two complex arrays with fft->transformSize() entries,
  // storing the result into a third array of the same size.
  void multiplyComplex(const Complex *m1, const Complex *m2,
		       Complex *dest) const
  {
    // experiment: use three real multiplies and 5 adds instead of 4 multiplies
    // and 2 adds.  Does this make any difference in the running time?
    for (int j = 0; j < transformSize(); j++)
      {
	double t1 = c_re(m1[j]) * c_re(m2[j]);
	double t2 = c_im(m1[j]) * c_im(m2[j]);
	
	c_re(dest[j]) = t1 - t2;
	c_im(dest[j]) = 
	  (c_re(m1[j]) + c_im(m1[j])) * (c_re(m2[j]) + c_im(m2[j])) - t1 - t2;
	
	//dest[j].re = (m1[j].re * m2[j].re - m1[j].im * m2[j].im);
	//dest[j].im = (m1[j].im * m2[j].re + m1[j].re * m2[j].im);
      }
  }
  
  //
  // Allocator routines to obtain appropriately aligned memory for
  // performing FFTs.
  //
  
  static FFT::Complex *allocAlignedComplex(size_t size) 
  { return (FFT::Complex *) malloc(size * sizeof(FFT::Complex)); }//fftw_malloc
  
  static void freeAlignedComplex(FFT::Complex *data)
  { delete [] data;}//fftw_free(data); }
  
private:
  
  int fftWidth, fftHeight;                // size of the FFT
  double *tempMatrix;
  fftw_plan forwardPlan, reversePlan;
  
  
  static bool wisdomLoaded;               // have we loaded the wisdom file?
  
  static bool loadWisdom(const char *);
  static bool saveWisdom(const char *);
};

#undef c_re
#undef c_im

#endif
