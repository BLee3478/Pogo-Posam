//
// POGO VISION
// Copyright (C) 2004 by the Institute for Systems Biology, Dave Orendorff. 
// All rights reserved.
// This code is distributed under the terms of the GNU Library General Public License.
// See COPYING for details.
//
// IMAGE.CPP
// Performs various low-level operations on an image. These include saving, loading 
// and simple transformations. Uses the structs defined in image.h.
// 

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include "libPNG\png.h"

#include "image.h"
#include "cameraimage.h"
#include "auxiliary.h"
#include "globals.h"
#include "processimage.h"

#include "window.h"

// overwrites the specified region of bigImage by small image. 
// pre: nothing null, top left are cordinates in big. This means accounts for RGB vals, too.
// post: return false if the image doesn't fit; otherwise copies 
//	the pixels (deep) from small onto big
bool littleImgOnBig(Image* big, Image* small, int left, int top, int nChannels, int channel){
	if (!inBounds(big, left, top) || 
		!inBounds(big, left + small->_width * (nChannels - 1) - 1 + channel, top + small->_height - 1))
		return false;

	for (int y = 0; y < small->_height; y++)
		for (int x = 0; x < small->_width; x++)
			setPixel(big, (x + left) * nChannels + (channel - 1), y + top, getPixel(small, x, y));

	return true;
}


// assumes all image in images are the same size
// makes a big image from all of the little images and sends it off to the normal writing function.
// pre: all images are defined and of the correct size; nChannels == 1 || 3; params legal
// any undefined images will be written as a black sheet in the scene.
int saveImages(char* szFileName, int compression, Image** images, 
				   int nRows, int nCols, int nChannels){
	assert(nCols > 0 && nRows > 0 && (nChannels == 1 || nChannels == 3));
	if (szFileName == NULL)
		return BAD_ARGUMENT;

	if (images == NULL || images[0] == NULL)
		return INTERNAL_DATA_NOT_DEFINED;

	int border = 5; // number of spacing pixels between pictures
	int width = (images[0]->_width + border) * nCols - border; 
		width *= nChannels;
	int height = (images[0]->_height + border) * nRows - border;
		height *= nChannels;

	Image* scene = newImage(width, height, new unsigned char[width * height * nChannels]);

	int length = nRows * nCols * nChannels;

	for (int row = 0; row < nRows; row++)
		for (int col = 0; col < nCols; col++)
			for (int chan = 0; chan < nChannels; chan++){

				int i = row  * nChannels * nCols + col * nChannels + chan;
				if (images[i] != NULL)
					littleImgOnBig(scene, images[i], (images[0]->_width + border) * ((i / nChannels) % nCols ),
						(images[0]->_height + border) * ((i / nChannels) / nCols ), nChannels, i % nChannels + 1);
	}


	// now just write it to disk
	writeToPNG(szFileName, scene, compression, nChannels);

	deleteImage(scene);	// cleanup

	return 0;
}

// TODO: the compression value causes error unless it is equal to 0
/* compression value:
                             -1: tEXt, none
                              0: zTXt, deflate
                              1: iTXt, none
                              2: iTXt, deflate  */
// comression, RGB or BW
int writeToPNG(char* szFileName, Image* image, int compression, int channels){

    FILE *fp = fopen(szFileName, "wb");

    if (!fp)
       return FILE_IO_ERROR;
 
	png_structp png_ptr = png_create_write_struct
       (PNG_LIBPNG_VER_STRING, png_voidp_NULL,
      png_error_ptr_NULL, png_error_ptr_NULL);

    if (!png_ptr)
       return UNKNOWN_ERROR;

    png_infop info_ptr = png_create_info_struct(png_ptr);
    if (!info_ptr)
    {
       png_destroy_write_struct(&png_ptr,
         (png_infopp)NULL);
       return UNKNOWN_ERROR;
    }

	// set up file reading for libPNG
	png_init_io(png_ptr, fp);

	// note: second to last parameter is compression
	png_set_IHDR(png_ptr, info_ptr, image->_width / channels, image->_height / channels,
		8, channels == 1 ? PNG_COLOR_TYPE_GRAY : PNG_COLOR_TYPE_RGB /*RGB || GREY*/,
		PNG_INTERLACE_NONE, PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);

	int height = image->_height / channels;
	png_bytep* row_pointers = (png_bytep*)png_malloc(png_ptr, height * sizeof(png_bytep));
		//(unsigned char**)malloc(height * sizeof(png_bytep));

	// set up the row array from image data from the image
	for (int i = 0; i < height; i++){
		row_pointers[i] = &image->_data[i * image->_width ];
	}


	// write each row to the info block

	png_set_compression_level(png_ptr, compression);
	png_set_rows(png_ptr, info_ptr, row_pointers);

	png_write_png(png_ptr, info_ptr, PNG_TRANSFORM_IDENTITY, NULL);

	png_free(png_ptr, row_pointers);
	png_destroy_write_struct(&png_ptr, &info_ptr);//&end_info

	fclose(fp);

	return 0;
}


// returns an array of (numchannals)Image pointers
Image* readFromPNG(char* szFileName){

	int readAhead = 8;
	unsigned char *header = new unsigned char[9];
	FILE *fp = fopen(szFileName, "rb");

    if (!fp){
        printf("\nNo file seen.");
		return NULL;
    }

    fread(header, 1, readAhead, fp);
    bool is_png = !png_sig_cmp(header, 0, readAhead);
    if (!is_png)
    {
        printf("\nNot a png file.");
		return NULL;
    }

	png_structp png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, png_voidp_NULL,
      png_error_ptr_NULL, png_error_ptr_NULL);

	if (!png_ptr)
        return NULL;

	png_infop info_ptr = png_create_info_struct(png_ptr);
    png_infop end_info = png_create_info_struct(png_ptr);

	// TODO: should free up memory if these are inline functions
	if (!info_ptr || !end_info)
		return NULL;

	// set up file reading for libPNG
	png_init_io(png_ptr, fp);

	// tell the library that we read ahead to check the signature
	png_set_sig_bytes(png_ptr, readAhead);

	// should result in an image without alpha and 8 bits per channel
	png_read_png(png_ptr, info_ptr, 
		PNG_TRANSFORM_STRIP_16 | PNG_TRANSFORM_STRIP_ALPHA | PNG_TRANSFORM_PACKING, NULL);

	unsigned long width, height;
	int bit_depth, color_type, interlace_type, compression_type, filter_method;

	// bit_depth - numbits / channel
	// color types: PNG_COLOR_TYPE_GRAY 0  PNG_COLOR_TYPE_PALETTE    PNG_COLOR_TYPE_RGB        PNG_COLOR_TYPE_RGB_ALPHA  PNG_COLOR_TYPE_GRAY_ALPHA 
	png_get_IHDR(png_ptr, info_ptr, &width, &height, &bit_depth, &color_type, &interlace_type,
       &compression_type, &filter_method);


	Image* aNewImage = newImage(width, height, new unsigned char[width*height]);

	// B&W
	int bytesPerPixel = -1;
	if (color_type == PNG_COLOR_TYPE_GRAY)
		bytesPerPixel = 1;
	
	/* already in our desired format */
	if(color_type == PNG_COLOR_TYPE_RGB)
		bytesPerPixel = 3;
		
	/* For now, just grab the first pixel from the set */
	if(bytesPerPixel > 0 && bit_depth == 8){
		// TODO: it would be wise to not allocate a whole new array that must be killed, but
		// allocating directly to the image is buggy
		png_bytep* row_pointers = (unsigned char**)malloc(height * sizeof(png_bytep) * bytesPerPixel);
		
		// copy the row pointers data to the image
		unsigned char **rows = png_get_rows(png_ptr, info_ptr);
		for (unsigned int i = 0; i < height; i++)
			for (unsigned int j = 0; j < width; j++)
				setPixel(aNewImage,j, i, rows[i][j * bytesPerPixel]);
		
		png_destroy_read_struct(&png_ptr, &info_ptr, &end_info);
		// TODO: could be memory leak here
		free(row_pointers);

		fclose(fp);

		return aNewImage;
	}

	return 0;	// should never get here
}

/** 
  It would be nice to use a templeted class for the pixels. However,
  I'm trying to stick to a c-style convention. 
 */
Image* newImage(int width, int height, unsigned char* data){
	Image* newimage = new Image;

	newimage->_data = data;
	newimage->_height = height;
	newimage->_width = width;

	return newimage;
}

Image* newImage(int width, int height){
	Image* newimage = new Image;

	newimage->_height = height;
	newimage->_width = width;
	newimage->_data = new unsigned char[width * height];

	return newimage;
}


FltImage* newFltImage(int width, int height, float* data){
	FltImage* newimage = new FltImage;

	newimage->_data = data;
	newimage->_height = height;
	newimage->_width = width;

	return newimage;
}


void deleteImage(Image* image){
	if (image == NULL) return;
	delete [] image->_data;
	delete image;
}


void deleteFltImage(FltImage* image){ 
	if (image == NULL) return;
	delete [] image->_data; 
	delete image;
}


void setPixel(Image* image, int x, int y, unsigned char pixel){
//	assert(x >= 0 && x < image->_width && y >=0 && y < image->_height);
	if (x < 0 || x >= image->_width || y < 0 || y >= image->_height)
		return;
	image->_data[image->_width*y + x] = pixel;
}

// black is returned if the pixel is not in image
unsigned char getPixel(Image* image, int x, int y){
	if (x < 0 || x >= image->_width || y < 0 || y >= image->_height)
		return 0;
	return image->_data[image->_width*y + x];
}

void setFltPixel(FltImage* image, int x, int y, float pixel){
	assert(x >= 0 && x < image->_width && y >=0 && y < image->_height);
	image->_data[image->_width*y + x] = pixel;
}

float getFltPixel(FltImage* image, int x, int y){
	assert(x >= 0 && x < image->_width && y >=0 && y < image->_height);
	return image->_data[image->_width*y + x];
}




//////////////  HARDWARE AQUISITION AND REMISSION    
/////////////////////////////////////////////////

Image* getImageFromCamera(){

	Image* newI = newImage(g_camWidth, g_camHeight,
			new unsigned char[g_camWidth*g_camHeight]);

	if( getGreyscale8BitCameraImage(g_camWidth, 
		g_camHeight, newI->_data) != 0 ){
		deleteImage(newI);
		return NULL;
	}
	
	return newI;
}


int writeImageToPPM(Image* image, char* szFileName){
	FILE* fp;

	
	if (szFileName == NULL ? (fp = fopen("camDump.ppm","wb")) == NULL : 
		(fp = fopen(szFileName,"wb")) == NULL)	
			return 1; 


	fprintf(fp,"P5\n%d %d\n255\n", image->_width, image->_height);  
	fwrite(image->_data,1,image->_width*image->_height,fp); 
	fclose(fp);  

	return 0;
}


// gets an image from PPM
// pre: PPM in P5 or P6 format, szFileName exists || NULL
// post: returns an image of demensions and size correlating to that of file
Image* getImageFromPPM(char* szFileName){

	FILE* fp;
	Image* image = new Image;
	
	if (szFileName == NULL ? (fp = fopen("camDump.ppm","r")) == NULL : 
		(fp = fopen(szFileName,"r")) == NULL)	
			return 0; 

	
	char* sz = new char[10];
	int pixBytes = -1; 

	// Parse to see what type of file we have here
	fscanf(fp,"%s", sz);
	if(!strcmp("P5",sz))	//greyscale, 1 byte per pixel
			pixBytes = 1;
	else if (!strcmp("P6",sz))
			pixBytes = 3;
	else
		return 0;

	fscanf(fp,"%d", &image->_width);
	fscanf(fp,"%d", &image->_height);
	fscanf(fp,"%s", sz);
	delete sz;

	if (image->_width < 5 || image->_height < 5)
		return 0;

	image->_data = new unsigned char[image->_height*image->_width + pixBytes - 1 ];

	int fileLen = image->_height*image->_width*pixBytes;

	if (pixBytes == 1)
		fread(image->_data, fileLen, 1, fp);

	else {
		deleteImage(image);
		return 0;
		unsigned char* szT = (unsigned char*)calloc(fileLen, 1);
		// TODO: fix, this next line often will not work.
		int lenRead = fread(szT, fileLen, 1, fp);
		
		for (int j = 0; j < fileLen; j++){
			if (szT[j] == NULL)
				lenRead++;
		}

		// I have to go about this in such a convoluted fashion because reading one 
		// at a time will sometimes mimick EOF
		for( int i = 0; i < image->_height*image->_width ; i++){
			//  just grabs the last byte of the (repeated?) set
			if(i % pixBytes == 0) image->_data[i] = sz[i];
		}
		delete [] sz;
	}


	fclose(fp);

	return image;

}


