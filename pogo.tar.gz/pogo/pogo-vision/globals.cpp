//
// POGO VISION
// Copyright (C) 2004 by the Institute for Systems Biology, Dave Orendorff. 
// All rights reserved.
// This code is distributed under the terms of the GNU Library General Public License.
// See COPYING for details.
//
// GLOBALS.CPP 
// Initializes the global variables.

#include <stdio.h>


#include "globals.h"
#include "image.h"


Image* g_spotsImg = NULL;
Image* g_blankImg = NULL;

Grid* g_grid = NULL;

// these change nowhere in the program
int g_camWidth = 1024;
int g_camHeight = 768;

// variables having to do with the window
// is there a window open in another thread?
bool g_windowOpen = false;

