//
// POGO VISION
// Copyright (C) 2004 by the Institute for Systems Biology, Dave Orendorff. 
// All rights reserved.
// This code is distributed under the terms of the GNU Library General Public License.
// See COPYING for details.
//
// AUXILIARY.CPP
// Contains various functions used throughout the program.

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <math.h>

#include "auxiliary.h"


/*
void swap(unsigned char &a, unsigned char &b){
	a ^= b;
	b ^= a;
	a ^= b;
}*/

void flipArray(unsigned char *array, int length){
	assert(array != NULL && length > 0);

	for (int i = 0; i < length/2; i++)	
		swap(array[i], array[length - i]);
}

void switchArrays(unsigned char *a1, unsigned char *a2, int length){
	for (int i = 0; i < length; i++)
		swap(a1[i], a2[i]);
}

/** 
	For every occuriance of the '\' charecter, another '\' is added after it.
	This is usefull when dealing with file locations where '\' is an escape 
	sequence.
	pre: sz is a null terminated string (0 length is okay)
	post: deletes the old sz and returns a new one. 
*/
char* dublicateBackslashes(char* sz){
	if (sz == NULL) return NULL;

	int nSlash = 0;
	char* lastSlash = strchr(sz, '\\');

	if(lastSlash == NULL) return sz;	// there are no '/'

	// count the number of '\' in the string
	for ( nSlash = 0; lastSlash != NULL; nSlash++, lastSlash = strchr(&lastSlash[1], '\\'));

	int newLength = strlen(sz) + nSlash;
		newLength++;	// for NULL termination
	char* szNew = new char[newLength];
	

	for(int iOld = 0, iNew = 0; iNew < newLength; iNew++, iOld++ ){
		if (sz[iOld] == '\\'){
			szNew[iNew++] = '\\';
		}
		szNew[iNew] = sz[iOld];
	}

	szNew[newLength - 1] = NULL;	// null terminate string

	delete [] sz;
	return szNew;
}


// selection sort in O(n^2) time, in place
// increasing order
void pixSort(unsigned char *pixels, int npixels){
	for (int i = 0; i < npixels -1; i++){
		if (pixels[i] > pixels[i+1]){ 
			// not in order
			// swap em, then back up, try again
			SWAP(pixels[i], pixels[i+1]);
			 i >= 1 ? i-=2 : i = -1 ;// counteract the i++ in "for...", and see if we need to swap these again
         }
    }
}
