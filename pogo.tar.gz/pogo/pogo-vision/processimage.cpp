//
// POGO VISION
// Copyright (C) 2004 by the Institute for Systems Biology, Dave Orendorff. 
// All rights reserved.
// This code is distributed under the terms of the GNU Library General Public License.
// See COPYING for details.
//
// PROCESSIMAGE.CPP
// The implementation of semi-complex transforms and image processing. 
//

#include <stdio.h>
#include <assert.h>
#include <math.h>

#include "processimage.h"
#include "image.h"
#include "auxiliary.h"


// used for Gaussian blur
static float* s_convolution = NULL;
static int s_convLength = 0;	// sizeof(s_convolution), should be odd


/**
	Flattens an image acording to the idea:
		newPixel = MAX_PIXEL * image_pixel(i) / blank_pixel(i)

	pre: image, blank != NULL; sizeof(image) == sizeof(blank)
	post; image is flattened according to blank as described in the procedure above. 
*/
int flattenImage(Image* image, Image* blank){
	assert(image != NULL && blank != NULL);
	
	int length = image->_width * image->_height;
	for(int i = 0; i < length; i++){
		float f = 255.0f * (float)(image->_data[i]);
		f /= (float)(blank->_data[i]);
		image->_data[i] = roundFltToInt(f);
	}
	return 0;
}


// true if the pixel location is in image
bool inBounds(Image* image, int x, int y){
	assert(image != NULL);
	return !(x < 0 || x >= image->_width || y < 0 || y >= image->_height);
}

bool inBoundsFlt(FltImage* image, int x, int y){
	assert(image != NULL);
	return !(x < 0 || x >= image->_width || y < 0 || y >= image->_height);
}

// flips an image about the horzontal &| vertical axis, in place
void flipImage(Image* image, bool flipH, bool flipV){
	assert(image != NULL);

	/* nothing to do */
	if (!flipH && !flipV)
		return;

	unsigned char* data = image->_data;
	int length = image->_height * image->_width;
	int i = 0;

	// easy case, just re-write the image data backwards
	if (flipH && flipV){
		flipArray(data, length);
		return;
	} if(flipH){
		// SWAP rows at a time
		for (; i < length/2; i += image->_width)
			switchArrays(&data[i], &data[length - i - image->_width], image->_width);
		return;
	}
	if (flipV){
		// reverse a row, 1 at a time
		for (; i < length; i += image->_width)
			flipArray(&data[i], image->_width);
		return;
	}

	// never get here
	assert(false);
}


/** 
	Copy all pixels (by value)
	pre: anImage != NULL && is valid
	post: returns a new image with same values as first but different location. 
*/
Image* deepCopy(Image* anImage){
	if (anImage == NULL) return NULL;

	Image* newOne = newImage(anImage->_width, anImage->_height, 
		new unsigned char[anImage->_width * anImage->_height]);
	
	int length = anImage->_width * anImage->_height;
	for(int i = 0; i < length; i++)
		newOne->_data[i] = anImage->_data[i];

	return newOne;	
}

// The new image must be contained in the old Image inclusive.
// The new image width and height MUST be inside of the oldImage. 
// Also, all data fields in newImage must be initialilzed. The data
// in the newI will be lost. 
//	pre: oldI, newI are defined; newI is inside of oldI.X, Y are the 
//		top left corner of the new image.
//  post: does a deep copy of the specified pixels from the old image 
//		into the new. 
bool subImage(Image* oldI, Image* newI, int x, int y){
	assert(newI != NULL && oldI != NULL);

	// O.B. ?
	if(!inBounds(oldI, x, y) || 
		!inBounds(oldI, x + newI->_width, y + newI->_height)) return false;


	int tX, tY;
	for(int newPix = 0; 
		newPix <= newI->_width*newI->_height; newPix++){

		// our current point in relation to the old image
		tX = newPix % newI->_width + x + 1; // not sure why +1, but it's right
		tY = newPix / newI->_width + y;

		newI->_data[newPix] = oldI->_data[oldI->_width*tY + tX];
	}
	return true;
}


// Process the pixels to modify the gamma setting,
//		where: gamma corrected pixel = pixel ^ gama
// pre: 0 < gammaFactor
// post: gammaCorrect(returned_pixel, gammaFactor^-1...) - old_pixel < epsilon
void gammaCorrect(Image* image, float gammaFactor){
	int length = image->_height * image->_width;

	
	int max = -1;
	int min = 1000;
	for ( int i = 0; i < length; i += 13){
		if (image->_data[i] > max) max = image->_data[i];
		else if (image->_data[i] < min) min = image->_data[i];
	}

	double maxGamma = pow(max, gammaFactor);
	double minGamma = pow(min, gammaFactor);

	double multiplier = 255.0 / (maxGamma - minGamma);

	for (int j = 0; j < length; j++){
		double pixelGamma = pow(image->_data[j], gammaFactor);
		// normalize and reinsert into image
		image->_data[j] = roundDbl((pixelGamma - minGamma) * multiplier);
	}
}


// Taken from DAPPLE
//
// negativeLaplacian()
// Given an image, return its *negative* Laplacian. More precisely, 
// given a 2D matrix F, compute a separable approximation to 
// L = -4*del^2(F), as follows:
//
// Let w = width(F) and h = height(F).
//
// - For all x and 1 <= y <= h-2, compute the 2nd-order column differences
//   Lc(x,y) = - [ ( F(x,y+1) - F(x,y) ) - ( F(x,y) - F(x,y-1) ) ]
//
// - For all y and 1 <= x <= w-2, compute the 2nd-order row differences
//   Lr(x,y) = - [ ( F(x+1,y) - F(x,y) ) - ( F(x,y) - F(x-1,y) ) ]
//
// - Define Lr(0,y) = Lr(1,y) and Lr(w-1,y) = Lr(w-2,y)
// - Define Lc(x,0) = Lc(x,1) and Lc(x,h-1) = Lc(x,h-2)
//
// - L(x,y) = Lr(x,y) + Lc(x,y)
//
// This is just the algorithm used by Matlab 5.1's del2() function,
// negated and without the normalization by 0.25 for each result pixel.
//
FltImage* negativeLaplacian(Image* image){
	int w = image->_width, h = image->_height;

	float* buf = new float[w*h];
	FltImage* result = newFltImage(w,h, buf);

	assert(w >= 3 && h >= 3);
  
	// Compute the column differences Lc for every row and
	// use them to initialize the result matrix.
	for (int x = 0; x < w; x++)
    {
		float pixel0 = (float)2.0 * getPixel(image, x, 1) - 
				getPixel(image, x, 0) - getPixel(image, x, 2);
      
		 setFltPixel(result, x, 0, pixel0);
		 setFltPixel(result, x, 1, pixel0);
		 
		for (int y = 2; y < h-2; y++)
		{
			 float pixel = (float)2.0 * getPixel(image, x, y) -
			 getPixel(image, x, y-1) - getPixel(image, x, y+1);
	  
			 setFltPixel(result, x, y, pixel);
		}
      
    float pixeln = (float)2.0 * getPixel(image, x, h-2) - 
		getPixel(image, x, h-3) - getPixel(image, x, h-1);
      
    setFltPixel(result, x, h-2, pixeln);
    setFltPixel(result, x, h-1, pixeln);
    }


	// Add the row differences Lr for every column into
	// the result matrix, forming the desired sum Lr + Lc. 
	for (int y = 0; y < h; y++)
    {
		float pixel0 = (float)2.0 * getPixel(image, 1, y) - 
			getPixel(image, 0, y) - getPixel(image, 2, y);
      
		setFltPixel(result, 0, y, getFltPixel(result, 0, y) + pixel0);
		setFltPixel(result, 1, y, getFltPixel(result, 1, y) + pixel0);
      
		for (int x = 2; x < w-2; x++)
		{
			float pixel = (float)2.0 * getPixel(image, x, y) - 
				getPixel(image, x-1, y) - getPixel(image, x+1, y);
	  
			setFltPixel(result, x, y, getFltPixel(result, x, y) + pixel);
		}
      
		float pixeln = (float)2.0 * getPixel(image, w-2, y) - 
			getPixel(image, w-3, y) - getPixel(image, w-1, y);
      
		setFltPixel(result, w-2, y, getFltPixel(result, w-2, y) + pixeln);
		setFltPixel(result, w-1, y, getFltPixel(result, w-1, y) + pixeln);
    }
  
	return result;

}




// Gaussian(d) = 1 / ((2 * PI) ^ .5 * sigma) * e^(-d^2 / (2 * s^2))
void calculateSmoothingConvolution(float sigma){
	assert(sigma > 0);
	if (s_convolution != NULL) delete [] s_convolution;
	s_convLength = int(sigma * 3 * 2) + 1; // always odd, needs to round down. 3 s.d. away
	s_convolution = new float[s_convLength];

	int convOver2 = s_convLength / 2;

	float overPISigRoot = 0.3989422f / sigma; // 1 / ((2 * PI) ^ .5 * sigma)
	float sigma2 = sigma * sigma;

	// a Gaussian distribution, symetric around middle
	s_convolution[convOver2] = overPISigRoot;
	for (int i = 1; i <= convOver2; i++){
		// could be sped up, but it shouldn't matter too much
		s_convolution[convOver2 - i] = float(overPISigRoot * exp(-(i * i) / (2 * sigma2)));

		s_convolution[convOver2 + i] = s_convolution[convOver2 - i];
	}
}

Image* smoothGaussian(Image* image, float sig){
	Image* smoothed = newImage(image->_width, image->_height);

	calculateSmoothingConvolution(sig);

	int length = image->_width * image->_height;

	unsigned char* data = image->_data;
	unsigned char* sdata = smoothed->_data;

	int x, y, offset, limit, i;
	unsigned char *fdata = smoothed->_data; 

	int convOver2 = s_convLength / 2;

	for (y = convOver2; y < image->_height - convOver2; y++){

		// convolve in the x direction
		for (x = convOver2; x < image->_width - convOver2; x++){
			i = y * image->_width ; 

			offset = MIN(i, convOver2); offset *= -1;
			limit = MIN(convOver2, length - i - 1);
			float convolution = 0;
			for (; offset <= limit; offset++){
				convolution += s_convolution[offset + convOver2] * (float)data[i + offset + x];
			}

			sdata[i + x] = roundFltToInt(convolution);
		}
	}
	
	// now the vertical direction
	unsigned char *result = new unsigned char[image->_height];
	unsigned char *source = new unsigned char[image->_height];
	for (x = 0; x < image->_width; x++){

		// effectly copy an entire column from the x convolution into source
		for (y = 0; y < image->_height; y++){
			source[y] = getPixel(smoothed, x, y); 
		}

		// convolve this array
		int convOver2 = s_convLength / 2;
		for (i = 0; i < image->_height; i++){
			int offset = MIN(i, convOver2); offset *= -1;
			int limit = MIN(convOver2, length - i - 1);
			float t = 0; //array[i];
			for (; offset <= limit; offset++){
				t += s_convolution[offset + convOver2] * (float)source[i + offset];
			}
			result[i] = roundFltToInt(t);
		}

		// copy it back into our final image
		for (y = 0; y < image->_height; y++)
			setPixel(smoothed, x, y, result[y]);

	}

	delete [] result; 
	delete [] source; 

	return smoothed;

}


///////////////////////////////////////////////////
////////////////////////////////////////// NOT USED

// inverts the given image
void invert(Image* image){
	for (int i = 0; i < image->_height*image->_width; i++)
		image->_data[i] = 0xFF - image->_data[i];
}

// not used.
//
// Taken from DAPPLE code
// First squash the pixels
// Second, return the negative laplacian of the squashed pixels
FltImage* prefilterPixels(Image* image, int squashFactor){
  
  unsigned char *pixels  = new unsigned char [image->_width * image->_height];
  int nPixels = image->_width * image->_height;

  pixSort(pixels, nPixels);

  unsigned char cutoff = pixels[MIN(int(squashFactor * nPixels), nPixels - 1)];
  delete [] pixels;
  
  Image* squashedImage = newImage(image->_width, image->_height, 
	  new unsigned char[image->_width * image->_height]);

  for (int j = 0; j < image->_width * image->_height; j++)
    squashedImage->_data[j] = MIN(image->_data[j], cutoff);
  
  FltImage* fltImage = negativeLaplacian(squashedImage);
  deleteImage(squashedImage);
  return fltImage;
}

// median filters the image. 
// Basic idea:
// - looks at a square grid of filterWidth around this pixel and 
//		then computes the median intensity, setting this pixel to that intensity. 
//
// filterWidth needs to be odd. 
//
// Time: O(n) * filterWidth ^ 2
Image* medianFilter(Image* image, int filterWidth){
	assert(filterWidth > 1 && filterWidth % 2 == 1);

	Image* filteredImg = newImage(image->_width, image->_height);

	// temp array, for sorting the surrounding pixels
	
	int halfWidth = filterWidth / 2; // we're counting on rounding down
	int widthSquared = filterWidth * filterWidth;

//unsigned char temp[9];
	unsigned char* neighbors = new unsigned char[widthSquared];

	for (int x = 0; x < image->_width; x++){
		for(int y = 0; y < image->_height; y++){
			int i = 0;

			for(int t_x = x - halfWidth; t_x <= x + halfWidth; t_x++){

				for(int t_y = y - halfWidth; t_y <= y + halfWidth; t_y++, i++){
					neighbors[i] = getPixel(image, t_x, t_y); 
				}
			}
			pixSort(neighbors, widthSquared); 
			setPixel(filteredImg, x, y, neighbors[widthSquared / 2 + 1]);
		}
	}

	

	delete [] neighbors;
	return filteredImg;
}