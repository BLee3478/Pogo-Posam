//
// POGO VISION
// Copyright (C) 2004 by the Institute for Systems Biology, Dave Orendorff. 
// All rights reserved.
// This code is distributed under the terms of the GNU Library General Public License.
// See COPYING for details.
//
// FINDSPOTS.H
// Interface to the spotfinding engine. 
// This algorithm mainly came from DAPPLE
//

#ifndef _FIND_SPOTS_H_
#define _FIND_SPOTS_H_

#include "image.h"

void startEngine(int iWidth, int iHeight,
		       int iMinRadius, int iMaxRadius,
		       int iRadiusFudgeFactor,
		       double iSquashFactor);

void killEngine();

double placeSpot(FltImage* pixels, int &finRadius, int &index);

// returns the radii range that are being checked for by the spotfinder
void getSpotfinderRadii(int &min, int &max);

#endif