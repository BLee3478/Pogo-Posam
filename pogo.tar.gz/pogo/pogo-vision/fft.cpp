//
// POGO VISION
// Copyright (C) 2004 by the Institute for Systems Biology, Dave Orendorff. 
// All rights reserved.
// This code is distributed under the terms of the GNU Library General Public License;
// See COPYING for details.
//
// FFT.CC
// Implementation of FFT library interface, based on the FFTW library.
//

// Because of _cdecl we are not using fftw_free, fftw_malloc. FFTW 
// documentation indicates that these are not required but only recomended. 
// In other words, it might increase speed to change this. 

#include <cstdio> // required for fftw wisdom file access
#include <cstring>
#include <cassert>
#include <stdlib.h>

#include "fft.h"
#include "globals.h"


// Has wisdom file been loaded?
bool FFT::wisdomLoaded = false;


//
// Constructor
// Create an FFT object for a particular FFT size [width * height].
// The user may then call fft2() and ifft2() with any matrix size not
// larger than the FFT size.
//
FFT::FFT(int iWidth, int iHeight)
  : fftWidth(iWidth), fftHeight(iHeight)
{
  fftw_complex *temp2;
  
  // attempt to load the FFT wisdom file.  Ignore the outcome; if the
  // load failed, we'll regenerate the wisdom below.
  if (!wisdomLoaded)
    {
		loadWisdom("");
		wisdomLoaded = true;
    }
  
  tempMatrix = (double *)malloc(fftWidth * fftHeight * sizeof(double));  // using malloc instread of fftw_malloc
  temp2 = (fftw_complex *)malloc(transformSize() * sizeof(fftw_complex));; // using malloc instread of fftw_malloc
  
  //
  // Compute plans for the forward and inverse FFT's.  Note that
  // Image pixel (x,y) is y * fftWidth + x, so row-major order
  // places the y dimension (height) first.
  //
  forwardPlan = 
    fftw_plan_dft_r2c_2d(fftHeight, fftWidth,
			 tempMatrix, temp2,
			 FFTW_MEASURE);
  
  reversePlan =
    fftw_plan_dft_c2r_2d(fftHeight, fftWidth,
			 temp2, tempMatrix,
			 FFTW_MEASURE);
  
  saveWisdom("");
  
  delete [] temp2;// not using fftw_free
}


//
// Destructor
// NOTE: This does not deallocate the FFT wisdom from the FFTW library.
//
FFT::~FFT()
{
  if (tempMatrix)
    delete [] tempMatrix;// not using fftw_free
  
  if (forwardPlan)
    fftw_destroy_plan(forwardPlan);
  
  if (reversePlan)
    fftw_destroy_plan(reversePlan);
}


//
// FFT::fft2()
// Perform an FFT on a 2D matrix of real values, storing the result in a 
// user-supplied matrix of complex values. If the real input size is less 
// than the FFT size, the real input is placed in the upper-left-hand 
// corner of the complex input matrix.
//
// NOTE: because the FFT input is real, the output is symmetric.  Hence,
// the result in dataOut is of size [fftWidth/2 + 1, fftHeight] (stored
// in row-major order), which elides the redundant part of the spectrum.
//
void FFT::fft2(const float *dataIn, Complex *dataOut, 
	       int dataWidth, int dataHeight)
{
  assert(fftWidth >= dataWidth && fftHeight >= dataHeight);
  
  // clear out the input matrix (relies on IEEE 0.0 == all zero bits)
  memset(tempMatrix, 0, fftWidth * fftHeight * sizeof(double));
  
  // initialize part of the input matrix with the data
	for (int y = 0; y < dataHeight; y++)
		for (int x = 0; x < dataWidth; x++)
		  tempMatrix[y * fftWidth + x] = dataIn[y * dataWidth + x];



  
  // perform the FFT using the "guru" interface -- ASSUMES that
  // alignment of dataOut is same as that used in planning!
  fftw_execute_dft_r2c(forwardPlan, tempMatrix, dataOut);
}


//
// FFT::ifft2_extract()
// Perform an inverse FFT of the current size on an array of complex
// values, storing the central portion of the result in a user-supplied
// matrix of floats.
//
// The extraction is performed under the assumption that the input
// data is the FFT of the convolution of a *real* matrix of size
// [dataWidth, dataHeight] with a *real* mask of size [maskWidth,
// maskHeight].  Because both inputs are real, the FFT is symmetric;
// hence, the FFT library needs only the first [fftWidth/2 + 1, fftHeight]
// of the spectrum to do the inverse transform.
//
// The returned values represent the central [dataWidth, dataHeight]
// of the convolution.
//
// NOTE: the input matrix dataIn is OVERWRITTEN with garbage.
//
// NOTE: the FFT output is not normalized.  To get normalized output,
// divide each value in dataOut by width() * height(), the FFT size.
//
void FFT::ifft2_extract(Complex *dataIn, float *dataOut,
			int dataWidth, int dataHeight,
			int maskWidth, int maskHeight)
{
  assert(fftWidth  >= dataWidth  + maskWidth  - 1 && 
	 fftHeight >= dataHeight + maskHeight - 1);
  
  // Perform the inverse FFT using the guru interface. ASSUMES
  // that alignment of dataIn is same as that used in planning!
  // NB: this operation will destroy dataIn.
  fftw_execute_dft_c2r(reversePlan, dataIn, tempMatrix);
  
  // Extract ONLY the central [dataWidth, dataHeight] of the result.
  // Assume that the matrices are in row-major order.  Using
  // integer division should work for odd or even mask sizes.

  int xlow = maskWidth/2;
  int ylow = maskHeight/2;
  
  int xhigh = xlow + dataWidth  - 1;
  int yhigh = ylow + dataHeight - 1;
  
  int dstidx = 0;
  for (int y = ylow; y <= yhigh; y++)
    for (int x = xlow; x <= xhigh; x++)
      dataOut[dstidx++] = (float)tempMatrix[y * fftWidth + x]; 
}


///////////////////////////////////////////////////////////////////////
// WISDOM MANAGEMENT
///////////////////////////////////////////////////////////////////////


// The Wisdom file is used by FFTW to store wisdom about how to do 
// FFT's fast on a given machine.
static const char WisdomFileName[] = "dapple-fft-wisdom.wiz";


//
// loadWisdom()
// Load the FFT wisdom file from the specified path on disk.
//
bool FFT::loadWisdom(const char *path)
{
  int status = 0;
  FILE *infile;
  
  infile = fopen(WisdomFileName, "r");
  if (!infile)
    return false;

  int bigSize = 10000;
  char *sz = new char[bigSize];

  // read wisdom from a file
  fgets(sz, bigSize, infile);

  // for some reason fftw_import_wisdom_from_file(infile) isn't working
  // so we have to do this workaround with strings
  status = fftw_import_wisdom_from_string(sz);
  
  delete [] sz;
  fclose(infile);
  
  return status != 0;
}


//
// saveWisdom()
// Save the FFT wisdom file to the specified path on disk.
//
bool FFT::saveWisdom(const char *path)
{
  FILE *outfile;
  
  outfile = fopen(WisdomFileName, "w");
  if (!outfile)
    return false;
  
  char* sz = new char[1000];
  sz = fftw_export_wisdom_to_string();
  fprintf(outfile, "%s", sz);

  fclose(outfile);
  
  return true;
}
