//
// POGO VISION
// Copyright (C) 2004 by the Institute for Systems Biology, Dave Orendorff. 
// All rights reserved.
// This code is distributed under the terms of the GNU Library General Public License.
// See COPYING for details.
//
// FINDSPOTS.CPP
// Implementation of yhe spotfinder and spot analyzer of POGO VISION. 
// With few modifications, this code came  
// from Jeremy Buhler's Dapple. 
//



#include <stdio.h>
#include <assert.h>
#include <math.h>

#include "findspots.h"
#include "globals.h"
#include "image.h"
#include "auxiliary.h"
#include "fft.h"

#include "window.h"


//
// finder parameters
//
static int imageWidth = -1;
static int imageHeight = -1;   // image dimensions

static int _minRadius, _maxRadius;    // range of spot sizes to check
static int _radiusFudgeFactor;        // diff. between inner and outer radii
static double _squashFactor;          // cutoff for high-intensity pixels

static int maskWidth;

static FFT *fft;                      // the FFT interface object for our ops

static FFT::Complex **maskDFTs;       // cached DFT's of masks


static FFT::Complex *fpixels, *fproduct; // temporary storage
static float *correlation;               // for convolutions

FltImage* negativeLaplacian(Image* image);
FltImage** precomputeMasks(int minradius, int maxradius);
FltImage* computeAnnularMask(int radius);



void startEngine(int iWidth, int iHeight,
		       int iMinRadius, int iMaxRadius,
		       int iRadiusFudgeFactor,
		       double iSquashFactor)
{
	imageWidth = iWidth; imageHeight = iHeight;
	_minRadius = iMinRadius; _maxRadius = iMaxRadius;
	_radiusFudgeFactor = iRadiusFudgeFactor; 
	_squashFactor = iSquashFactor;

	assert(imageWidth > 0 && imageHeight > 0);

	FltImage** annularMasks = precomputeMasks(_minRadius, _maxRadius);
	int maskDim = annularMasks[_maxRadius]->_width; // (square mask)

	int convWidth  = imageWidth  + maskDim - 1;
	int convHeight = imageHeight + maskDim - 1;

	// nextpow2 makes FFT fast
	fft = new FFT(nextpow2(convWidth), nextpow2(convHeight));	

	// Allocate temporary arrays for DFT computations.
	// NOTE: the funky width is due to the real/complex transform 
	// optimization of libFFTW, which produces only half the
	// (symmetric) complex spectrum when doing an fftWidth * fftHeight
	// transform on a real input.
	fpixels     = FFT::allocAlignedComplex(fft->transformSize());
	fproduct    = FFT::allocAlignedComplex(fft->transformSize());
	correlation = new float [imageWidth * imageHeight];

	// Precompute DFT's of convolution masks
	maskDFTs = new FFT::Complex * [_maxRadius + 1];

	for (int r = 0; r < _minRadius; r++)
		maskDFTs[r] = NULL;

	for (int radius = _minRadius; radius <= _maxRadius; radius++)
	{
		FFT::Complex *dft = FFT::allocAlignedComplex(fft->transformSize());
		FltImage* mask = annularMasks[radius];


		fft->fft2(mask->_data, dft, mask->_width, mask->_height);
		maskDFTs[radius] = dft;

		deleteFltImage(mask);
	}

	return;
}


// deallocate all of the static variables used  
void killEngine(){
	for (int radius = _minRadius; radius <= _maxRadius; radius++)
		if (maskDFTs[radius])
		 FFT::freeAlignedComplex(maskDFTs[radius]);
  
	delete [] maskDFTs;

	if (correlation) delete [] correlation;
	if (fproduct)    FFT::freeAlignedComplex(fproduct);
	if (fpixels)     FFT::freeAlignedComplex(fpixels);

	if (fft)         delete fft;

	imageWidth = -1;
	imageHeight = -1;

}

// usefull to see if the engine has started yet
void getSpotfinderRadii(int &min, int &max){
	min = _minRadius;
	max = _maxRadius;
}


// This is where the majority of the calculations take place
// 
// Returns a spots brightness (circularity + distinctness)
double placeSpot(FltImage* pixels, int &finRadius, int &index)
{
  double globalBestScore;
  int globalBestIdx = 0;
  int bestRadius    = 0;



  // Compute the DFT of the image into fpixels.
  fft->fft2(pixels->_data, fpixels, imageWidth, imageHeight);
  
  //
  // find the highest scoring combination of spot radius and center
  //
  globalBestScore = -1.0;
	for (int radius  = _minRadius;
       radius     <= _maxRadius;
       radius++)
	{
		  const FFT::Complex *fmask = maskDFTs[radius];
		  int maskDim               = maskWidth; // square mask
		  int bestIdx = 0;
		  double bestScore;
      
		  fft->multiplyComplex(fpixels, fmask, fproduct);
      
		  // Get just the central [imageWidth, imageHeight] of the correlation.
		  fft->ifft2_extract(fproduct, correlation, 
				 imageWidth, imageHeight,
				 maskDim, maskDim);
      
//showFltImage(newFltImage(imageWidth,imageHeight,correlation)); 
		 // Find the highest-scoring location for the image center.
		bestScore = -1.0;
		for (int j = 0; j < imageWidth * imageHeight; j++)
		{
			if (correlation[j] > bestScore)
			{
				bestScore = correlation[j];
				bestIdx   = j;
			}
		}
  
		// Have we done better than any other radius tried thus far? 
		if (bestScore > globalBestScore)
		{
			globalBestScore = bestScore;
			globalBestIdx   = bestIdx;
			bestRadius      = radius;
		}
    }
	
	
  // Choose the best center for the spot
  index = globalBestIdx;

  //
  // This is a crude way to adjust the spot radius from the inner to the
  // outer radius.  We use it only for lack of a better idea about what 
  // the spot's outer regions look like.
  //
  finRadius = MAX(2, (MIN(bestRadius + _radiusFudgeFactor, _maxRadius)));
  return globalBestScore;
}



//
// precomputeMasks()
// Computing all masks between the specified minimum and maximum radii,
// in single-pixel increments.
//
// NOTE: The annular mask DFTs must subsequently be computed by calling 
// initMaskDFTs().
//
FltImage** precomputeMasks(int minradius, int maxradius)
{
	FltImage** annularMasks = new FltImage*[maxradius +1];

	// Compute any masks in the specified range that don't exist.
	for (int r = minradius; r <= maxradius; r++)	
    {
			annularMasks[r] = computeAnnularMask(r);
    }

	return annularMasks;
}


//
// computeAnnularMask()
// Compute an annular mask of specified radius, with a normal edge profile
// of specified standard deviation.  The mask is normalized to have unit
// total energy; that is, the the squares of its pixel values sum to one.
//
// The size size will be that of the standard vignette size.
//
static FltImage* computeAnnularMask(int radius)
{
  const int sdev   = 2;  // in pixels
  const int nsdevs = 3;  
  
  
  int dim = MAX(g_grid->_dx, g_grid->_dy);
	dim += 1 - dim%2;		 // add one to dim if width is even
  int c   = dim/2;           // center index of the image
  FltImage* image = newFltImage(dim, dim, new float[dim*dim]);
  maskWidth = dim;

  double vscale = -1.0/(2 * sdev * sdev);  // normal scale for variance
  
  // render the mask
  for (int y = 0; y <= dim/2; y++)
    for (int x = 0; x <= y; x++)
      {
	double d = sqrt( double(x * x + y * y) );
	double diff = d - radius;
	float v = (float)exp(vscale * diff * diff);
	
	// duplicate the rendered pixel across the eight
	// symmetric octants of the circle.
		setFltPixel(image, c + x, c + y, v);
		setFltPixel(image, c + y, c + x, v);
		setFltPixel(image, c - x, c - y, v);
		setFltPixel(image, c - y, c - x, v);
		setFltPixel(image, c + x, c - y, v);
		setFltPixel(image, c + y, c - x, v);
		setFltPixel(image, c - x, c + y, v);
		setFltPixel(image, c - y, c + x, v);
      }
  
  // Create a mask with this 
  // Normalize the mask to have unit total energy by dividing by
  // # pixels * the RMS intensity.
  double norm = 0.0;
  for (int j = 0; j < image->_width * image->_height; j++)
	{
		double pixel = image->_data[j];
		norm += pixel * pixel;
  }

  norm = sqrt(norm);
  
  double inorm = 1.0/norm;
  for (int k = 0; k < image->_width * image->_height; k++)
    image->_data[k] = (float)inorm * image->_data[k];
  
  return image;
}

