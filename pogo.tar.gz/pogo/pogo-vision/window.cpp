//
// POGO VISION
// Copyright (C) 2004 by the Institute for Systems Biology, Dave Orendorff. 
// All rights reserved.
// This code is distributed under the terms of the GNU Library General Public License.
// See COPYING for details.
//
// WINDOW.CPP
// This is a simple set of Window functions that throw up a window
// which paints our given image.
//
// Hitting escape or closing the window will exit. Additionally, this
// function may be initialized in a new thread by a host program. Therefore,
// thread interactions have been established between this and the host 
// caller. 
//
// Secret Keys: 
//	Ctrl-s: shows that the finder found. 
//	Ctrl-o shows the edges of the image. NOTE: leaks ~2mb per hit!
//

#include <windows.h>
#include <stdio.h>
#include <assert.h>
#include <time.h>
#include <process.h>
#include <math.h>

#include "image.h"
#include "globals.h"
#include "auxiliary.h"
#include "grid.h"


// for the secret functions
#include "processimage.h"	
#include "anotherfindspots.h"
#include "vision.h"

#include "resource.h" 


/* this is the function that Windows will call when something interesting happens
   in our window; in the code below, we'll tell Windows to use this function;
   the function parameters/return value are defined by Windows */
LRESULT CALLBACK WndProcMain(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

/* this is our function to handle drawing the contents of the window */
void PaintWindow(HWND hwnd);

/* draw the circles found by the spotfinder */
void drawCircles(HDC hdc);

/* this function draws the grid on top of the given hdc */ 
void drawGrid(HDC hdc, Grid* grid, COLORREF mask);

/* draw the points that were clicked un, shape corisponds to the corner clicked on */
void drawPoints(HDC hdc);

HINSTANCE s_hinst;
static HWND hwndMain = NULL;

/* the image to paint. */ 
static Image* s_image;

// where the user clicks on the screen 
static int s_top = -1;		// TR click point
static int s_left = -1;	
static int s_bottom = -1;	// BL click point
static int s_right = -1;
static int s_mTop = -1;		// TL click point
static int s_mRight = -1;

static bool s_drawCircles = false;

// how much the image will be shrunk when displayed, range: 1-n
static int s_shrinkFactor = 1; 

// is the grid shown over the spots?
static bool s_gridShown = false;


/* this is like the "main" function for Windows; it is what will be run when our function starts;
   the function can not easily return values, because it is in a threaded context. 

	note: __cdecl is required for a function that will be threaded. 
*/
void __cdecl showImage(void* i)
{
	if (i == NULL || g_windowOpen)
		return;

	s_image = (Image*)i;

	time_t t = time(NULL);
//	char* szTitleBar = ctime(&t);	// display the time as the tittle bar name
	char* szTitleBar = "Pogo Image";

	/* re-init our pointer variables. */ 
	s_top = -1;		// TR
	s_left = -1;
	s_bottom = -1;	// BL
	s_right = -1;
	s_mTop = -1;		// TL click point
	s_mRight = -1;
	s_drawCircles = false; 

	/* this is the name for the window class we're going to create */
	char* szWndClassMain = szTitleBar;

	WNDCLASSEX wc;
	MSG msg;


	/* create the window class we'll use; we set the fields of the
	   WNDCLASSEX structure to specify the settings we want */
	memset(&wc, 0, sizeof(wc));				// clear the structure
	wc.cbSize = sizeof(wc);
	wc.style =  NULL;				
	wc.lpszClassName = szWndClassMain;		// name for this window class
	wc.lpfnWndProc = WndProcMain;			// call this function with messages, primary
	wc.hInstance = NULL; //hinst;
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hIcon = LoadIcon(NULL, (LPCTSTR)IDI_POGO);
//	wc.hIcon = loadPOGOIcon();//(wc.hInstance, MAKEINTRESOURCE(IDI_POGO)); ////TODO: fix

//	printf("\nError code: %d", GetLastError());


	/* register the window class; once this is done, we can create windows
	   based on the properties we specified in the WNDCLASSEX struct */
	if (RegisterClassEx(&wc) == 0){
		printf("\nError code: %d", GetLastError());
		return;		// class registration failed; exit
	}

	/* create our window */
	hwndMain = CreateWindow(
		szWndClassMain,					// use the window class we created above
		szTitleBar,						// the text for the title bar
		WS_OVERLAPPED | WS_SYSMENU | WS_CAPTION| WS_MINIMIZEBOX ,	// type of window we want
		0, 0, //CW_USEDEFAULT, CW_USEDEFAULT,	// default left, top
		s_image->_width/s_shrinkFactor, MAX(50, s_image->_height/s_shrinkFactor), // width, height
		NULL, NULL, 
		,NULL//hinst
		, NULL);


	if (hwndMain == NULL)
		return;		// window creation failed; exit
	
	g_windowOpen = true;	// thread variable letting the host know we are open
	s_hinst = NULL;			// hinst;

//	LoadIcon(s_hinst, "smallpogo.ico");

	/* show the window */
	ShowWindow(hwndMain, 1); // nCmdShow);
	/* force an update (so the contents are drawn) */
	UpdateWindow(hwndMain);

	/* this loop will get any messages that are sent to our program; this includes
	   keystrokes, mouse moves, and mouse clicks */
	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	DestroyWindow(hwndMain);

	UnregisterClass(szWndClassMain, NULL);
	
	g_windowOpen = false;
	hwndMain = NULL;
	return;
}


/* when something interesting happens in our window, this function will be called */
LRESULT CALLBACK WndProcMain(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

	switch (msg)
	{
	case WM_PAINT:
		/* we'll get a paint message when Windows decides we need to refresh
		   the contents of the window, e.g. if it's been resized */
		PaintWindow(hwnd);
		return 0;

	case WM_DESTROY:
		/* we'll receive this message to notify us that our program should shut down */
		PostQuitMessage(0);
		return 0;

	case WM_CHAR:
		/* close our program if the user presses escape */
		if (wParam == VK_ESCAPE)
			SendMessage(hwnd, WM_CLOSE, 0, 0);
		if (wParam == 19){	// Ctrl-s
			// shows the spot overlay
			s_drawCircles = true; 
			InvalidateRect(hwnd, NULL, 0);
		}
		if (wParam == 15){	// Ctrl-o	
			// show outlines of the spots
			zeroCrossings(negativeLaplacian(s_image), s_image);
		// leak memory, oh well, it's a feature
			InvalidateRect(hwnd, NULL, 0);
		}
		return 0;
	
	case WM_LBUTTONUP:
		// get the position of the mouse cursor, refresh.
		s_left = lParam & 0x0000FFFF;
		s_top = (lParam & 0xFFFF0000) >> 16;
		InvalidateRect(hwnd, NULL, 0);
		return 0;
	case WM_MBUTTONUP:
		// get the position of the mouse cursor, refresh.
		s_mRight = lParam & 0x0000FFFF;
		s_mTop = (lParam & 0xFFFF0000) >> 16;
		InvalidateRect(hwnd, NULL, 0);
		return 0;

	case WM_RBUTTONUP:
		// get the position of the mouse cursor, refresh.
		s_right = lParam & 0x0000FFFF;
		s_bottom = (lParam & 0xFFFF0000) >> 16;
		InvalidateRect(hwnd, NULL, 0);
		return 0;
	}

	/* if we didn't handle the message, pass it along to the default window procedure */
	return DefWindowProc(hwnd, msg, wParam, lParam);
}


/* draw the window */
void PaintWindow(HWND hwnd)
{
	PAINTSTRUCT ps;
	HDC hdc;
	RECT rcWindow;

	/* tell Windows we're painting; this will give us an HDC 
	   that we can use for draw commands, and it will fill the PAINTSTRUCT structure
	   with information about our window */
	hdc = BeginPaint(hwnd, &ps);
	/* set mode where each unit corresponds to a pixel, positive x is to the right,
	   and positive y is down */
	SetMapMode(hdc, MM_TEXT);
	/* get the rectangle for our window */
	GetClientRect(hwnd, &rcWindow);


	/* draw the pixels of s_image, one by one. */
	int x, y;
	int width = rcWindow.right - rcWindow.left;
	int height = rcWindow.bottom - rcWindow.top; 

	for (int row = 0; row < s_image->_height; row += s_shrinkFactor)
		for (int col = 0; col < s_image->_width; col += s_shrinkFactor){
			// map pixels onto screen
			x = col / s_shrinkFactor;	
			y = row / s_shrinkFactor;
			unsigned char pixel = s_image->_data[row*s_image->_width+col];

			SetPixel(hdc, x, y, RGB(pixel,pixel,pixel));
		}

	// draw grid with a green mask
	if (g_grid != NULL && s_gridShown)
		drawGrid(hdc, g_grid, RGB(0, 255, 0));
	
	drawPoints(hdc);
	if (s_drawCircles)
		drawCircles(hdc);

	/* tell Windows we're done painting */
	EndPaint(hwnd, &ps);
}



void killWindow(){
	if (hwndMain != NULL){
		SendMessage(hwndMain, WM_CLOSE, 0, 0);
		ShowWindow(hwndMain, SW_SHOW);
	} else 	g_windowOpen = false;
}

/** 
	Gets the cordinates of the rectangle created by user clickings.
*/
void getEdges(int &x1, int &y1, int &x2, int &y2, int &x3, int &y3){
	x1 = s_left;
	y1 = s_top;
	x2 = s_mRight;
	y2 = s_mTop;
	x3 = s_right;
	y3 = s_bottom; 
}

bool setShrinkFactor(long shrinkFactor){
	if (shrinkFactor < 1)
		return false;

	s_shrinkFactor = shrinkFactor;
	return true;
}

void isGridShown(bool shown){
	s_gridShown = shown;
}


//////////////////////////////////////////////////////////////
///////////////////////////////////// Special Drawing Functions

/**
	Draws a scaled version of our grid onto the window. 
	The drawn version is actually a mask with the pixel at location i. 
	pre: hdc, grid are okay
	post: origionalPixel[i] & mask = newImagePixel[i]--for all grid lines 
*/
void drawGrid(HDC hdc, Grid* grid, COLORREF color){
	if (hdc == NULL || grid == NULL)
		return;

	// deminsions our grid will be on the window
	long startX = (grid->_left)/s_shrinkFactor;
	long startY = (grid->_top)/s_shrinkFactor;

	long width = (grid->_right - grid->_left)/s_shrinkFactor;
	long height = (grid->_bottom - grid->_top)/s_shrinkFactor;

	// draw the horizontal lines
	int dummy;
	int x, y; 

	// draw horizontal lines
	int row = 0;
	for (y = startY; y <= grid->_bottom/s_shrinkFactor && y >= 0; ){
			getVignette(grid, row++, 0, dummy, y);
			if(y < 0) break;	// O.B.

			y /= s_shrinkFactor;

			for (x = startX; x < width + startX; x++){ // = grid->_left; 
				// long pixel = GetPixel(hdc, x, y);
				// apply the color to grid areas 
				SetPixel(hdc, x, y, color);
			}
	}

	// draw verticle lines
	int col = 0;
	// progress through the loc. of each verticle line
	for (x = startX; x <= grid->_right/s_shrinkFactor && x >= 0; ){
		getVignette(grid, 0, col++, x, dummy);
		if(x < 0) break;	//  O.B.

		x /= s_shrinkFactor;

		// draw the line
		for (y = startY; y < height + startY; y++){ // = grid->_left; 
			//long pixel = GetPixel(hdc, x, y);
			// apply a "mask" to grid areas 
			SetPixel(hdc, x, y, color);
		}
	}
}

#define lineLengths 50 // how long the crosshair lines are
void drawPoints(HDC hdc){
	//draw the pointed locations...(where the user clicked)
	if(s_left >= 0 || s_right >= 0 || s_mRight >= 0){	// any button been clicked?

		COLORREF colorTR = (COLORREF)RGB(0, 0, 255);
		COLORREF colorBR = (COLORREF)RGB(255, 0, 0);
		COLORREF colorTL = (COLORREF)RGB(0, 255, 0);

		for (int i = -5; i < lineLengths; i++){
			SetPixel(hdc, s_left , s_top + i, colorTR);
			SetPixel(hdc, s_left + i, s_top , colorTR);

			SetPixel(hdc, s_right , s_bottom - i, colorBR);
			SetPixel(hdc, s_right - i, s_bottom , colorBR);

			SetPixel(hdc, s_mRight - i, s_mTop, colorTL);		// vert
			SetPixel(hdc, s_mRight, s_mTop + i, colorTL);	// horz
		}
	}
}

/** 
	draw a circle 
*/
void drawCircle(HDC hdc, COLORREF color, int x, int y, int radius){
	int dx = 0;
	int dy = radius; 
	int decision = 3 - (2 * radius); 

	
	// start from the very top and calc the first PI / 4 going right
	while (dx <= dy)
	{
		SetPixel(hdc, x + dx, y + dy, color); 
		SetPixel(hdc, x + dx, y - dy, color); 
		SetPixel(hdc, x - dx, y + dy, color); 
		SetPixel(hdc, x - dx, y - dy, color); 
		SetPixel(hdc, x + dy, y + dx, color); 
		SetPixel(hdc, x - dy, y + dx, color);
		SetPixel(hdc, x + dy, y - dx, color);
		SetPixel(hdc, x - dy, y - dx, color);

		if (decision < 0) 
			decision += (4 * dx) + 6;
		else{
			decision += 4 * (dx - dy) + 10;
			dy--;
		}
		dx++;
	}

	// center dot
	SetPixel(hdc, x, y, RGB(0, 0, 255));
}


/** 
	Draws the found spots on the screen
	note: not implemented in release dll, this function used for testing only
*/
void drawCircles(HDC hdc){

	if (g_grid == NULL)
		return;

	// when finding radius from the area
	double multiplier = 1.0 / pow(3.141, .5);

	int maxQuality = 999;

	for (long row = 0; row < g_grid->_rows; row++){
		for (long col = 0; col < g_grid->_cols; col++){
			long dx, dy, area, quality;

			int error = GetFeatureInfo( row,  col,  dx,  dy,  area, quality);
//			printf("\nQuality: %d", quality);
			maxQuality = MAX( quality, maxQuality);

			int x, y;
			getVignette(g_grid, row, col, x, y);
	
			// center of circle
			int cX = x + g_grid->_dx/2 + dx + 1;
			int cY = y + g_grid->_dy/2 + dy + 1;
			
			//RGB(255 * (float) quality / 72000RGB(quality  + 200, 0, 0)
			// area = pi * r^2
			drawCircle(hdc, RGB(255,0,0), cX, cY, roundDbl(pow(area, .5) * multiplier));
		}
	}

}



///////////////////////////////////////////////
//////////////////////////// NOT CHANGED OFTEN

/**
	First converts float image to a one expressed as unsigned chars, then calls
	the default showImage function. 
*/
void __cdecl showFltImage(void* flt){

	// cast our void to a FltImage
	FltImage* image = (FltImage*)flt;

	assert(image != NULL);

	int npix = image->_height*image->_width;

	Image* temp = newImage(image->_width, 
		image->_height, new unsigned char[npix]);

	float smallest = 999, largest = -999;
	for (int i = 0; i < npix; i++){
		image->_data[i] > largest ? largest = image->_data[i] : 
	(image->_data[i] < smallest) ? smallest = image->_data[i] : smallest = smallest ;
	}

	assert (smallest != 999 && largest != -999);

	/* normalize and mult by 255.0*/
	float multiplier = 255.0f / (largest - smallest);	
	for (int j = 0; j < npix;j++){
		temp->_data[j] = roundFltToInt((image->_data[j] - smallest)*multiplier);
	}

	showImage(temp);

	deleteImage(temp);
	return;
}