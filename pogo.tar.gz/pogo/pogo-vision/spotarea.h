//
// POGO VISION
// Copyright (C) 2004 by the Institute for Systems Biology, Dave Orendorff. 
// All rights reserved.
// This code is distributed under the terms of the GNU Library General Public License.
// See COPYING for details.
//
// SPOTAREA.H
// Interface. 
// Tries to find the exact area of a spot given its approximate location
// and radius.
//

#ifndef _SPOT_AREA_H_
#define _SPOT_AREA_H_

#include "image.h"


/**
	Returns the area of the spot in pixels. It returns -1 if it can not use 
	the given spot. 
	Unit of length is the pixel. 
*/
int spotArea(FltImage* theVignette, int theXCord, int theYCord, int theRadius);




#endif 
