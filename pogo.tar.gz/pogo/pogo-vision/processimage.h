//
// POGO VISION
// Copyright (C) 2004 by the Institute for Systems Biology, Dave Orendorff. 
// All rights reserved.
// This code is distributed under the terms of the GNU Library General Public License.
// See COPYING for details.
//
// PROCESSIMAGE.CPP
// 

#ifndef _PROCESS_IMAGE_H_
#define _PROCESS_IMAGE_H_

#include "image.h"
#include "auxiliary.h"


Image* medianFilter(Image* image, int filterWidth);

/**
	Flattens an image acording to the idea:
		newPixel = MAX_PIXEL * image_pixel(i) / blank_pixel(i)

	pre: image, blank != NULL; sizeof(image) == sizeof(blank)
	post: image is flattened according to blank as described in the procedure above. 
*/
int flattenImage(Image* image, Image* blank);

/**
	Every pixel in the image becomes the opposite color. 
	newPixel = PIXEL_MAX - oldPixel
*/
void invert(Image* image);

/** 
	Copy all pixels (by value)
	pre: anImage != NULL && is valid
	post: returns a new image with same values as first but in a different location. 
*/
Image* deepCopy(Image* anImage);

/**
	returns a shallow copy of the specified region. That is, the subimage data points to pixels 
	in oldI. The new rect must be contained in the old Image inclusive
    If newI does not fit in oldI based off of the data members in newI, then false is returned.

	pre: oldI, newI != NULL; newI has the desired rectangle size; top left is the corner to
		begin being copied;
	post: returns true if the sub image was successfully put into newI. False if it didn't happen.
*/
bool subImage(Image* oldI, Image* newI, int top, int left);

/** 
	Flips the image in place. A value of true for flipHorizonatal &| flipVertical 
	results in an image manipulation of that type.

	time: O(n)
	pre: image != NULL
	post: flipImage(same parameters) results in the origional image. 
*/
void flipImage(Image* image, bool flipH, bool flipV);


/** Process the pixels to modify the gamma setting,
		where: gamma_corrected_pixel = pixel ^ gama

	pre: 0 < gammaFactor; valid(image)
	post: gammaCorrect(returned_pixel, gammaFactor^-1...) - old_pixel < epsilon
*/
void gammaCorrect(Image* image, float gammaFactor);


// true if the cordinate is in the image
bool inBounds(Image* image, int x, int y);
bool inBoundsFlt(FltImage* image, int x, int y);

// get an image ready to analyzed
FltImage* prefilterPixels(Image* image, int squashFactor);

// 2nd derivitive of an image based on color values. See source code 
// for algorithm. 
FltImage* negativeLaplacian(Image* image);

// blurs the image with parameter sigma
// note: leaves the edge pixels of (sig * 3) pixels NULLED. 
Image* smoothGaussian(Image* image, float sig);

// Implemented in affine.cpp
void fastAffine(Image* image, int x1, int y1, int x2, int y2, int x3, int y3);
void qualityAffine(Image* image, int &x1, int &y1, int &x2, int &y2, int &x3, int &y3);

#endif 