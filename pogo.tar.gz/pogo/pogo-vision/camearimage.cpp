//
// POGO VISION
// Copyright (C) 2004 by the Institute for Systems Biology, Dave Orendorff. 
// All rights reserved.
// This code is distributed under the terms of the GNU Library General Public License;
// See COPYING for details.
//
// CAMERAIMAGE.CPP
// Opens, snaps a picture and closes the IEEE camera using 1394camera.dll

#include <windows.h>
#include <stdio.h>
#include <1394camera.h>

#include "cameraimage.h"
#include "globals.h"

// pre: sizeof(data) = width*height; 
// post: data contains the raw bytes of the picture taken
int getGreyscale8BitCameraImage(int width, int height, unsigned char* data){
	C1394Camera theCamera;  
	unsigned char* buf = new unsigned char[width*height*3];


	if(theCamera.CheckLink() != CAM_SUCCESS)    return CAMERA_NOT_FOUND; 

	if(theCamera.InitCamera() != CAM_SUCCESS)    return CAMERA_ERROR;    /* assume we can do 640x480 YUV4:1:1 @ 30 fps */  

	// TODO: correlate these to the given heigth/width
	theCamera.SetVideoFormat(1);  
	theCamera.SetVideoMode(5); 
	theCamera.SetVideoFrameRate(0); 

	if(theCamera.StartImageCapture() != CAM_SUCCESS)    return CAMERA_ERROR; 

	if(theCamera.CaptureImage() != CAM_SUCCESS)    return CAMERA_ERROR; 
	
	theCamera.getRGB(buf);  
	theCamera.StopImageCapture(); 

	// convert to greyscale
	for (int i = 0; i < width*height; i++){
		// could use the general rule for luminance: Lum=0.3RED+0.59GREEN+0.11Blue
		// but since it already is in greyscale, just steal the Red channel
		data[i] = buf[3 * i];
	}

	delete [] buf;


	return 0;
}

