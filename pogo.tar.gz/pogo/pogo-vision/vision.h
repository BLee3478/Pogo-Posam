//
// POGO VISION
// Copyright (C) 2004 by the Institute for Systems Biology, Dave Orendorff. 
// All rights reserved.
// This code is distributed under the terms of the GNU Library General Public License.
// See COPYING for details.
//
// VISION.H
//
// The program dll interface to all of the dll functions. 
//
// It is assumed that the caller program deals in 32bit integers/floats.
// See comments above each function to see what they do.
//

#ifndef _VISION_H_
#define _VISION_H_


#define DEBUG_MODE

// use another spotfinder or...
//#define USE_DAPPLE_ALG 1	// not using DAPPLE algorthm if this line is commented

// get area calculated from the radii as opposed to the area from the seperate algorthm
//#define NOT_USE_ADV_AREA 1	// only if not commented


#define DllExport  __declspec(dllexport) 
#define MY_CALLBACK //__stdcall



///////////////////////////////////// Image Aquisition
//////////////////////////////////////////////////////
/** 
	Take a picture using the digital video camera. 
	This will overwrite a previous picture in the buffer.
*/
extern "C" DllExport long MY_CALLBACK PhotographSpots();


/**
	Photograph the slide that will be used for field flattening.
*/
extern "C" DllExport long MY_CALLBACK PhotographBlank();



//////////////////////////////////// Image Processing
/////////////////////////////////////////////////////
/**
	Flattens the buffered image according to the blank photograph. It is important to
	not have the image already be gamma corrected or else the results will be undefined.
*/
extern "C" DllExport long MY_CALLBACK ApplyFlattening();

/**
	Smooths the image according to a Gaussian distribution. 
	It is very important that this function be called before running the spotfinder.
	A parameter of 0 smooths to a default level. 
*/
extern "C" DllExport long MY_CALLBACK GaussianSmoothing(float sigma);

/**
	Flip Image
	the flip* parameters are really boolean. For example, if flipHorizontal
	is true then the image in the buffer will be flipped(mirrored) horizontally. 
*/
extern "C" DllExport long MY_CALLBACK FlipSpots(int flipHorizontal, int flipVertical);

/**
	Apply gamma correction on the image. This is fairly perminant but 
	can be mostly reversed by calling ApplyGamma(1/gamma). 
	Tries to minimize loss of information. 
*/
extern "C" DllExport long MY_CALLBACK ApplyGamma(float gamma);


///////////////////////////// Pre-spotfinding functions
///////////////////////////////////////////////////////

/**
	Set the geometry that will be used by the engine. 
	The 1st point corisponds to the center of the top-left most spot to be analyzed. 
	The 2nd point corisponds to the center of the top-right spot to be analyzed.
	The 3rd point corisponds to the center of the right-bottom spot to be analyzed.

	numSpots* corrisponds to the number of spots to be analyzed in the x, y directions.
	If the 2nd point is not defined (-1, -1) then no affine is performed. However, the 
	grid region will still be set. 
*/
extern "C" DllExport long MY_CALLBACK SetRegion(long x1, long y1, long x2, long y2, long x3, long y3, long numSpotsX, long numSpotsY);


/**
	This is a fairly expensive function. The spotfinder engine is started.

    Though other size spots will be analyzed, the min/max radius parameters are spot sizes that 
	will be looked for directly. 
	ZeroTolerance is used for the new spotfinder. See the documentation for what it does. You can just leave 
	it as zero if you don't want to mess with it and it should be okay. 
	Note: specifying too small or too large arguments may result in poor speed and reduce spot finding capability.  
*/
extern "C" DllExport long MY_CALLBACK SetSpotFinderParameters(long MinRadius, long MaxRadius, long ZeroTolerance);



////////////////////////////////////////// Spotfinding
//////////////////////////////////////////////////////
/**
	Returns the attributes of the given spot based off of its row and collumn. 
	Values are passed by reference. 

	The "quality" argument indicates the spot's goodness--a value based on roundness and 
	contrast. 

	note: right now this functions does a lot of checks for internal data consistency. 

*/
extern "C" DllExport long MY_CALLBACK GetFeatureInfo(long row, long col, long &dx, long &dy, long &area, long &quality);



/////////////////////////////// visualization functions
///////////////////////////////////////////////////////
/**
	Begins a new thread that is a display of the spots. 
	Does not modify anything. 
	
	Note: this function will first need to close any open windows.
    
*/
extern "C" DllExport long MY_CALLBACK ShowSpots(long shrinkFactor);	


/**
	Closes the window if it is open. There is a timer on this so it will not lock up
	the host program if, for some reason, the window will not close.
*/
extern "C" DllExport long MY_CALLBACK CloseSpotWindow();

/**
	Sets whether or not the grid is shown when the spots are displayed. 
	This parameter can be set anytime. 
*/
extern "C" DllExport long MY_CALLBACK  GridShown(long shown);

/**
	Returns the pixels clicked on by the left, middle and right mouse buttons. 
	SetRegion is expecting these to be the middle of the 
		<top left>, <top right>, <bottom right> spots respectively. 
	If the user has not clicked a particular button, -1's are returned for uninitialized variables. 

*/
extern "C" DllExport long MY_CALLBACK GetUserCreatedRectangle(long &x1, long &y1, long &x2, long &y2, long &x3, long &y3);


/////////////////////////////////// META scene functions
////////////////////////////////////////////////////////
/**
	The meta image is the composite image of all the photos that comprise 
	the entire slide.
	This is because the camera cannot take a picture of the entire slide in one shot.
*/

/** 
	Sets up all of our information about the meta image
	doesn't work if there has already been one setup unless
	destroy is called.
	Valid values for the number of channels are: 1,3 representing monochrom and RGB respectively.
*/
extern "C" DllExport long MY_CALLBACK SetupMetaImage(long nRows, long nCols, long nChannels);


/**
	Puts the current image into the tile specified by these cordinates.
	Erases the current image that is in the 'buffer' and sets it to null.
	If there is already an image in this location then that image will be deleted first.
*/
extern "C" DllExport long MY_CALLBACK InsertTile(long row, long col, long channel);


/** 
	Saves the meta image to the specified file location.
	Any channels or tiles that have not been written to will be black.

	compression correlates to the amount of compression used in the underlying 
	zlib library. Valid values are 0-9. Testing indicates the optimal values are 1-4. 

	The file name is meant to be in human readable form, 
	ie: "D:\hello.png" is good while "D:\\hello.png" is bad
*/
extern "C" DllExport long MY_CALLBACK SaveMetaImage(char* szFileName, long compression);


/**
	Dealocates all of the information in the meta image.
	No recovery afterwards if there has been no save to disk explicitely.
*/
extern "C" DllExport long MY_CALLBACK DestroyMetaImage();



////// debug-mode functions. Note: these functions are not robust.
//////////////////////////////////////////////////////////////////
#ifdef DEBUG_MODE

/** 
	Loads an image from the png file, "virtualspots.png. It must be local.
*/
extern "C" DllExport long MY_CALLBACK PhotographVirtualSpots();

// for flattening. Uses local file "virtualblank.png"
extern "C" DllExport long MY_CALLBACK PhotographVirtualBlank();

// long SetCameraMode(format, mode);	// not implemented

#endif 

#endif
