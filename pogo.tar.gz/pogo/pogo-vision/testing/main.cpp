//
// POGO VISION
// Copyright (C) 2004 by the Institute for Systems Biology, Dave Orendorff. 
// All rights reserved.
// This code is distributed under the terms of the GNU Library General Public License.
// See COPYING for details.
//
// MAIN.CPP
//	Provides a messy workbench for testing VISION more directly than
//  the DLL can. 
//
//  note: this file should not be compiled into the final DLL.
//


#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <assert.h>
#include <process.h>
#include <time.h>
#include <iostream.h>

#ifndef NOT_USE_VISION_H
#include "..\vision.h"
#endif



//#ifdef NOT_USE_VISION_H
#include "..\\globals.h"
#include "..\\image.h"
#include "..\\processimage.h"
#include "..\\window.h"
#include "..\\auxiliary.h"
#include "..\\findspots.h"
#include "..\\grid.h"
#include "..\\spotarea.h"
#include "..\\anotherfindspots.h"
//#endif

#include "../libPNG/png.h"



void withDLL();
void withoutDLL();
void testSpotfinding();
void testAffine();
void testAffineDLL();
void testFilter();
void testOutline();
void setGeometry();


__cdecl int main(){
	PhotographVirtualSpots();

	setGeometry();
	GridShown(true);
	GaussianSmoothing(0);
	SetSpotFinderParameters(5, 10, 0);
	ShowSpots(1);



//	testSpotfinding();
	getch();
	return 0;
}


void check(int error){
	if(	error != 0) 
		printf("\nError: %d", error);
}

void testOutline(){
	PhotographVirtualSpots();

	showImage(g_spotsImg);
	Image* outline = newImage(g_spotsImg->_width, g_spotsImg->_height);
//	invert(g_spotsImg);
	time_t t = clock();
	LaplacianOfGausian(g_spotsImg, outline, 1.4);
	printf("time: %d\n", clock() - t);
	showImage(outline);

}

void testFilter(){
	PhotographVirtualSpots();
//	showImage(g_spotsImg);
//	invert(g_spotsImg);
	time_t t = clock();
	Image* filtered = medianFilter(g_spotsImg, 1);
	printf("\median filter time: %d", clock() - t);
//	invert(filtered);
	showImage(filtered);
}

void setGeometry(){
//	ShowSpots(1);
//	long x1 =200, y1=170, x2=400,y2=200, x3=350,  y3=400;
//	getch();
//	GetUserCreatedRectangle(x1 , y1, x2,y2, x3,  y3);
//	SetRegion(x1, y1, x2,y2, x3,  y3, 7, 7);
	
	SetRegion(33, 31, -1, -1, 675, 492, 30, 22);
//	printf("Stuff: %d, %d, %d, %d", x1, y1,x3, y3);

}


void threashhold(Image* image, unsigned char cutoff){
	for ( int i = 0; i < image->_width * image->_height; i++){
		image->_data[i] > cutoff ? image->_data[i] = 100: image->_data[i] = 0;
	}
}


void testSpotfinding(){
	PhotographVirtualSpots();

	int nRows = 33;
	int nCols = 44;

	long top, left, bottom, right;
	setGeometry();

	check(SetSpotFinderParameters(3, 10, 0));

	// note: memleak
	g_spotsImg = smoothGaussian(g_spotsImg, 1);	// ~350 ms, doesn't work well on the edges
	showImage(g_spotsImg);
	//30x22

//	zeroCrossings(negLap, outline);						// ~190 ms

//	g_spotsImg = medianFilter(g_spotsImg, 5);
//	LaplacianOfGausian(g_spotsImg, outline, 1.4);
//	allInOne(g_spotsImg, outline, 1.4);


	Image* origional = g_spotsImg;
//	g_spotsImg = outline;
//	showImage(origional);
//	showImage(outline);

//	GridShown(true);
//	ShowSpots(1);
//	getch();


//	g_spotsImg = medianFilter(g_spotsImg, 3);

	long dx, dy, area, quality;

	for (int i = 0; i < 1000; i++){
		printf("\ngo!");
		time_t t = clock();
		for (int r = 0; r < nRows; r++)
			for (int c = 0; c < nCols; c++){
				GetFeatureInfo(r, c, dx, dy, area, quality);
		//		printf("\ndx: %d, dy: %d, area: %d, quality: %d", dx, dy, area, quality);
			}

		printf("\ntime: %d\n", clock() - t);
	}

	GridShown(true);
	ShowSpots(1);
	while(true);
//	getch();

//	GetUserCreatedRectangle(top, left, bottom, right);


}

void testAffineDLL(){
	PhotographVirtualSpots();
	ShowSpots(1);
	long x1 =200, y1=170, x2=400,y2=200, x3=350,  y3=400;
	getch();
	GetUserCreatedRectangle(x1 , y1, x2,y2, x3,  y3);

	for (int i = 0; i < 1; i++){
	time_t t = clock();
		check(SetRegion(x1 , y1, x2,y2, x3,  y3, 22, 20));
		printf("\naffine time: %d", clock() - t);
	}
	GridShown(true);
	ShowSpots(1);
	getch();



}
void testAffine(){
//	Image* image = readFromPNG("..\\samplePics\\pic.png");
	Image* image = readFromPNG("rotated.png");
	int x1 =200, x2=400, x3=400, y1=200, y2=150, y3=400;

//	qualityAffine(image, x1, y1, x2, y2, x3, y3);
//	writeToPNG("rotated.png", image, 1, 1);
	showImage(image);



	for (int i = 0; i < 10; i++){
		time_t t = clock();
		// dumb affine is ~350 ms. 
		// medium affine in ~1360 ms. (nearest neibor)
		// smart affine in ~1480 ms. (bilinear)
//		qualityAffine(image, 200, 200, 400, 150, 400, 400);
		printf("\nTime: %d", clock() - t);
		showImage(image);
	}
}

void testSavePng(){

	int nRows = 2;
	int nCols = 3;
	int nChannels = 1;


	check(PhotographSpots());



	for (int i = 0; i < 10; i++){
		check(SetupMetaImage(nRows, nCols, nChannels));
		printf("\nTaking pictures...");
		for (int r = 0; r < nRows; r++)
			for(int c = 0; c < nCols; c++){
				for(int chan = 1; chan <= nChannels; chan++){
					check(PhotographVirtualSpots());
					check(FlipSpots(r%2, (c/2)));
					check(InsertTile(r,c,chan));

				}

	
			}
		char *szFileName = new char[20];
		sprintf(szFileName, "data\\%d.png", i);

		printf("\t\tSaving %s...", szFileName);

		for (int j = 0; j < 10; j++){
			szFileName = new char[20];
			sprintf(szFileName, "data\\%d.png", j);

			clock_t t = clock();
		check(SaveMetaImage(szFileName, j));	// i is compression
			printf(" \n...done in: %d seconds", clock() - t);
		}

		check(DestroyMetaImage());
		return;

	}

	printf("\nSaving image...");
	check(SaveMetaImage("saved.png", 0));


}



void withOutDLL(){

		GridShown(false);
	//PhotographVirtualSpots();

	Image* image = readFromPNG("..\\samplePics\\pic.png");

	Image** images = (Image**)calloc(10, sizeof(Image));

	images[0] = image;

	images[1] = readFromPNG("..\\samplePics\\pic.png");
	images[2] = readFromPNG("..\\samplePics\\pic.png");
	images[3] = readFromPNG("..\\samplePics\\pic.png");

	images[4] = readFromPNG("..\\samplePics\\pic.png");
	images[5] = readFromPNG("..\\samplePics\\pic.png");
	images[6] = readFromPNG("..\\samplePics\\pic.png");

	images[7] = readFromPNG("..\\samplePics\\pic.png");
	images[8] = readFromPNG("..\\samplePics\\pic.png");
	images[9] = readFromPNG("..\\samplePics\\pic.png");

	//flipImage(images[1], 1, 0);
	//flipImage(images[2], 0, 1);

	//invert(images[2]);
	flipImage(images[3], 1, 1);
	flipImage(images[4], 1, 1);
	flipImage(images[5], 1, 1);

	flipImage(images[6], 0, 1);
	flipImage(images[7], 0, 1);
	//flipImage(images[8], 0, 1);
	//flipImage(images[9], 1, 1);

	//showImage(image);

	//PhotographVirtualBlank();

	//ApplyFlattening();
	//if(PhotographVirtualSpots()) printf("error2");
	printf("starting to save");
	for (int i = 0; i < 300; i++){
		saveImages("scene.png", 0, images, 1, 1, 3);
		printf("done saving");
	}
}