//
// POGO VISION
// Copyright (C) 2004 by the Institute for Systems Biology, Dave Orendorff. 
// All rights reserved.
// This code is distributed under the terms of the GNU Library General Public License.
// See COPYING for details.
//
// AFFINE.CPP
// Implementation of an affine transformation on an image. 
//
// This should actually be in processimage.cpp, but these 
// procedures should easily be portable to other programs. 
//
//
// Affines are transpositions of an image, they use the formula:
//			x2 = A*x1 + B
//
//	where x1 is the origional pixel location, A is a 2D matrix, B is a 1x2 array and x2 
//  is the final pixel location. We actually treat A, B as one but sticking them both
//	in a 6 element long array. (The first 4 belong to A and the last 2 are B's). 
//
//  To transpose an image, we first must find A, B. and then solve for all x2 from x1. 
//	The main difficulty is that sometimes a x1 pixel does not map squarly onto transposed space.
//	There are two solutions in this file
//		1. grab the nearest pixel from where it is mapped to, and use this value (linear interpolation)
//		2. start in x2 space and map backwards (find the inverse of A, B), and then average the
//			nearest 4 pixels to this location. (bilinear interpolation). 
//


#include <stdio.h>
#include <math.h>

#include "processimage.h"
#include "image.h"
#include "auxiliary.h"


/**
 * Do an affine transformation of a point.
 * (x, y) are mapped into the space specified by affine. 
 * @affine: The affine transformation.
 **/
void
affine_point (int srcX, int srcY, int &dstX, int &dstY, const float affine[6], int Ox, int Oy)
{
  float x = float(srcX);
  float y = float(srcY);

  dstX = roundFltToInt((x - Ox)* affine[0] + (y - Oy) * affine[2] + affine[4] + Ox);
  dstY = roundFltToInt((x - Ox) * affine[1] + (y - Oy) * affine[3] + affine[5] + Oy);
}

/**
 * Do an affine transformation of a point.
 * (x, y) are mapped into the space specified by affine. 
 * @affine: The affine transformation.
 **/
void
affine_point_float (int srcX, int srcY, float &dstX, float &dstY, const float affine[6], int Ox, int Oy)
{
  float x, y;

  x = (float)srcX;
  y = (float)srcY;
  dstX = (x - Ox)* affine[0] + (y - Oy) * affine[2] + affine[4] + Ox;
  dstY = (x - Ox) * affine[1] + (y - Oy) * affine[3] + affine[5] + Oy;

}


/**
 * Multiply two affine transformation matrices.
 * @src1: Where to store the result.
 * @src1: The first affine transform to multiply.
 * @src2: The second affine transform to multiply.
 *
 * Multiplies two affine transforms together, i.e. the resulting
 * is equivalent to doing first @src1 then @src2. Note that the
 * PostScript concat operator multiplies on the left, i.e.  "M concat"
 * is equivalent to "CTM = multiply (M, CTM)";
 *
 **/
void
affine_multiply (float src1[6], const float src2[6])
{
  float d0, d1, d2, d3, d4, d5;

  d0 = src1[0] * src2[0] + src1[1] * src2[2];
  d1 = src1[0] * src2[1] + src1[1] * src2[3];
  d2 = src1[2] * src2[0] + src1[3] * src2[2];
  d3 = src1[2] * src2[1] + src1[3] * src2[3];
  d4 = src1[4] * src2[0] + src1[5] * src2[2] + src2[4];
  d5 = src1[4] * src2[1] + src1[5] * src2[3] + src2[5];
  src1[0] = d0;
  src1[1] = d1;
  src1[2] = d2;
  src1[3] = d3;
  src1[4] = d4;
  src1[5] = d5;
}


/**
 * Set up a rotation affine transform.
 * @dst: Where to store the resulting affine transform.
 * @theta: Rotation angle in radians.
 *
 * Sets up a rotation matrix. In the standard coordinate
 * system, in which increasing y moves downward, this is a
 * counterclockwise rotation. In the standard PostScript coordinate
 * system, which is reversed in the y direction, it is a clockwise
 * rotation.
 **/
void
affine_rotate (float dst[6], double theta)
{
  float s, c;

  s = (float)sin (theta);
  c = (float)cos (theta);
  dst[0] = c;
  dst[1] = s;
  dst[2] = -s;
  dst[3] = c;
  dst[4] = 0;
  dst[5] = 0;
}


/**
 * Set up a shearing matrix.
 * @dst: Where to store the resulting affine transform.
 * @theta: Shear angle in degrees.
 *
 * Sets up a shearing matrix. In the standard libart coordinate system
 * and a small value for theta, || becomes \\. Horizontal lines remain
 * unchanged.
 **/
void
affine_shear (float dst[6], double theta)
{
  float t;

  t = (float)tan (theta);// * M_PI / 180.0);
  dst[0] = 1;
  dst[1] = 0;
  dst[2] = t;
  dst[3] = 1;
  dst[4] = 0;
  dst[5] = 0;
}

/**
 * Find the inverse of an affine transformation.
 * @affine: The original affine transformation, where the result will be stored.
 *
 * All non-degenerate affine transforms are invertible. If the original
 * affine is degenerate or nearly so, expect numerical instability and
 * very likely core dumps on Alpha and other fp-picky architectures.
 * Otherwise, @origional multiplied with @result
 * will be (to within roundoff error) the identity affine.
 **/
void
affine_invert (float affine[6])
{
  float r_det;
  float d0, d1, d2, d3, d4, d5;

  r_det = (float)1.0 / (affine[0] * affine[3] - affine[1] * affine[2]);

  d0 = affine[3] * r_det;
  d1 = -affine[1] * r_det;
  d2 = -affine[2] * r_det;
  d3 = affine[0] * r_det;
  d4 = -affine[4] * d0 - affine[5] * d2;
  d5 = -affine[4] * d1 - affine[5] * d3;

  affine[0] = d0; affine[1] = d1;affine[2] = d2;
  affine[3] = d3; affine[4] = d4; affine[5] = d5;

}

/* set up a translation matrix */
void
affine_translate (float dst[6], float tx, float ty)
{
  dst[0] = 1;
  dst[1] = 0;
  dst[2] = 0;
  dst[3] = 1;
  dst[4] = tx;
  dst[5] = ty;
}


/* returns a new image based on the given 3 points of a rectangle.
* pt1 = TL, pt2 = TR, pt3 = BR
* returned affine will have perpendicular angles and be parallel to the horizontal
*/
void getAffineMatrix(float affine[6], int x1, int y1, int x2, int y2, int x3, int y3){
	float temp_affine[6];

	// we want to know the angle that the top two points make with the horizontal
	double rotation = -atan((double)(y2 - y1) / (double)(x2 - x1));

	// the angle between pt2, pt3 w.r.t. the vertical 
	double shear = -atan((double)(x3 - x2) / (double)(y3 - y2));

	affine_rotate( affine, rotation);

	affine_shear( temp_affine, shear + rotation);

	// order does matter. Result stored in affine
	affine_multiply(affine, temp_affine);

}


/* get the average pixel value around this one based on its location in relation to
* the other pixels.
* edges will tend to fade, btw. 
* function tries to be tricky and optimized. 
*/
unsigned char bilinearInterpolation(Image *image, float x, float y){
	x -= 0.5f; y -= 0.5f; // shift everything into int-pixel space, ie: pixel at <1, 2> in int-space
					  // is really at <1.5, 2.5> in float-space

	// check the floor and ceiling to get our adjacent pixels, uses tricky inline _asm code
	int xL = roundFltToInt(x - (float).5);	// aka:  floorf(...) function, but fast
	int yL = roundFltToInt(y - (float).5); 

	if (xL < 0 || yL < 0)
		return 0;

	// get the fractional part
	x -= xL; 
	y -= yL;

	/* take the area of the fractional part of each edge, and then multiply this 
	   area by the pixels on the opposite corner. */

	// multiplyiers
	float TL = (1.0f - x) * (1.0f - y);
	float BR = x * (1.0f - y);
	float TR = (1.0f - x) * y;
	float BL = x * y;

	return (unsigned char)(BL * getPixel(image, xL + 1, yL + 1) + BR * getPixel(image, xL + 1, yL) +
		TR * getPixel(image, xL, yL + 1) + TL * getPixel(image, xL, yL));		
}


/** this is another affine transform, it averages pixels so that rotations are smooth by using bilinear interpolation
*
*	Points 1, 2 and 3 are the top-left, top-right, bottom-right respectivly of the 
*	rectangle that is wanted to be perpindicular and level to the horizontal. 
*
* Game plan: 
*	figure out the affine transform based on the given rectangle.
*	Find the inverse of this affine and map back to origional space.
*	When in origional space, find the average pixel intensity from the float cordinates
*		and put this value on to the final image. 
*
*	Space: not in place, (n) * 2
*	Time: ~O(n) * 4
*/
void qualityAffine(Image* image, int &x1, int &y1, int &x2, int &y2, int &x3, int &y3){
	float inv_affine[6]; 

	getAffineMatrix(inv_affine, x1, y1, x2, y2, x3, y3);
	
	// map it backwards
	affine_invert(inv_affine);

	int w = image->_width;
	int h = image->_height;
	Image* tempImage = newImage(w, h, new unsigned char[w*h]);
	float realX, realY; 

	for (int x = 0; x < w; x++)
		for (int y = 0; y < h; y++){
			affine_point_float(x, y, realX, realY, inv_affine, x1, y1);

			// -0.5 allows for float pixel space, see bilearInterpolation(...)
			if (inBounds(image, roundFltToInt(realX - (float).5), roundFltToInt(realY - (float).5))){
				unsigned char intensity = bilinearInterpolation(image, realX, realY);
				setPixel(tempImage, x, y, intensity);			
			}
		}
 
	// need to see how the cordinates where changed
	affine_invert(inv_affine); 
	affine_point(x3, y3, x3, y3, inv_affine, x1, y1);
	affine_point(x2, y2, x2, y2, inv_affine, x1, y1);

	delete [] image->_data;
	image->_data = tempImage->_data;
	tempImage->_data = NULL;
	delete tempImage;
}

////////////////////////////////////////////////////////
/////////////////////////////////////////////// NOT USED
/* grab the nearest pixel
*/
unsigned char linearInterpolation(Image *image, float x, float y){
	x -= .5; y -= .5;
	return getPixel(image, roundFltToInt(x), roundFltToInt(y));
}

/* Same as quality affine with the key differences:
	The inverse affine is not calculated. 
	Each pixel in the origional image is mapped directly on to the 
	new (affined) image. 

	Time: O(n)
	Space: (n) * 2
*/
void fastAffine(Image* image, int x1, int y1, int x2, int y2, int x3, int y3){

	float affine[6]; 

	getAffineMatrix(affine, x1, y1, x2, y2, x3, y3);

	int w = image->_width;
	int h = image->_height;
	Image* tempImage = newImage(w, h, new unsigned char[w*h]);
	int mappedX, mappedY; 
	for (int x = 0; x < w; x++)
		for (int y = 0; y < h; y++){
			affine_point(x, y, mappedX, mappedY, affine, x1, y1);

			if (inBounds(image, mappedX, mappedY))
				setPixel(tempImage, mappedX, mappedY, getPixel(image, x, y));
		}

	delete [] image->_data;
	image->_data = tempImage->_data;
	tempImage->_data = NULL;
	delete tempImage;
}


// converts the chars into numbers
char* printArray(unsigned char *x, int length){
        char* sz = new char[length * 5];       // 3 chars per number, plus comma and space
        char* szTemp = sz;

        // note: sprintf does not return NULL character as written
        szTemp = &szTemp[sprintf(szTemp, "\n")];
        for( int i = 0; i < length; i++){
                szTemp = &szTemp[sprintf(szTemp, "%d, ", x[i])];
        }

        szTemp[-2] = NULL;
        return sz;
}

