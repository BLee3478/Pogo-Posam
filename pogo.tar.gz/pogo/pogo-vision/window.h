//
// POGO VISION
// Copyright (C) 2004 by the Institute for Systems Biology, Dave Orendorff. 
// All rights reserved.
// This code is distributed under the terms of the GNU Library General Public License.
// See COPYING for details.
//
// WINDOW.H
// Interface to displaying a window. While a window is open the buffer image should 
// not be modified. 
//

#ifndef MAKE_WINDOW_H_
#define MAKE_WINDOW_H_

#include "image.h"

void __cdecl showImage(void* i);

void __cdecl showFltImage(void* flt);

// returns the points clicked on by left, middle and right buttoms respectively
void getEdges(int &x1, int &y1, int &x2, int &y2, int &x3, int &y3);

// returns true when the variable has been set
bool setShrinkFactor(long shrinkFactor);

void isGridShown(bool shown);

void killWindow();

#endif 