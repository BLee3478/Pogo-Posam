
// does pretty much the same thing as findspots.h, but without 
// the fftw. This requires more image filtering but runs much quicker. 

#ifndef ANOTHER_FIND_SPOTS_H
#define ANOTHER_FIND_SPOTS_H

#include "image.h"

void zeroCrossings(FltImage* conv, Image* bOut);

void setupHough(int width, int height, int minRad, int maxRad, int zeroTol);

int houghCircle(Image* edges, int &globalIndex, int &bestRadius);

void getHoughRadii(int &min, int &max);

// not used
void LaplacianOfGausian(Image* origional, Image *outline, float sigma);


#endif 