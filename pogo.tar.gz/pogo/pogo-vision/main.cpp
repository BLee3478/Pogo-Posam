/* * Sample 1394 camera application 
* * Captures a single frame from the camera and writes  
* it to disk as a Portable Pixel Map (ppm) *  
* Don't forget to add "1394camera.lib" under 
* Project->Settings->Link : "Object/Library Modules" * 
* Christopher Baker * tallbaker@cmu.edu */


#include <windows.h>
#include <1394camera.h>
#include <stdio.h>

#include "cameraimage.h"
#include "image.h"
#include "globals.h"

// #define VIRTUAL_CAMERA	/* camera not needed for debug, use file instead. */ 




int main(){  

	int width = 1024, height = 768;
	unsigned char* pic = new unsigned char[1024*768];

	getGreyscale8BitCameraImage(width, height, pic);
	Image* image = newImage(width, height, pic);

	if(writeImageToPPM(image, NULL)){
		printf("\nerror writing to disk.\n");
	}


	Image* newImage2 = getImageFromPPM("camDump.ppm");

	if(writeImageToPPM(newImage2, "secondDump.ppm")){
		printf("\nerror writing to disk.\n");
	}

	deleteImage(image);
	deleteImage(newImage2);

	return 0;
}


