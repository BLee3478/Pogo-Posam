//
// POGO VISION
// Copyright (C) 2004 by the Institute for Systems Biology, Dave Orendorff. 
// All rights reserved.
// This code is distributed under the terms of the GNU Library General Public License.
// See COPYING for details.
//
// IMAGE.H
// Defines the Image structs.
// Interface the accessor functions for an Image.
// There is functionallity for images of byte or float data
//


#ifndef _IMAGE_H_
#define _IMAGE_H_




// We should really use a templated type class for the 
// different types of images. For now, everything is in twos

struct Image{
	unsigned char* _data;
	int _width, _height;

};

struct FltImage{
	float* _data;
	int _width, _height;
};


Image* deepCopy(Image* anImage);

FltImage* newFltImage(int width, int height, float* data);
Image* newImage(int width, int heigth, unsigned char* data);
Image* newImage(int width, int height);


void deleteImage(Image* image);
void deleteFltImage(FltImage* image);


void setPixel(Image* image, int x, int y, unsigned char pixel);

// black is returned if the pixel is not the image
unsigned char getPixel(Image* image, int x, int y);

void setFltPixel(FltImage* image, int x, int y, float pixel);
float getFltPixel(FltImage* image, int x, int y);


// writes image in P5 PPM format
int writeImageToPPM(Image* image, char* szFileName);

// pre: PPM in P5 or P6 format, szFileName exists || NULL
// post: returns an image of demensions and size correlating to that of file
Image* getImageFromPPM(char* szFileName);

// right now this only reads B&W images
Image* readFromPNG(char* szFileName);

int saveImages(char* szFileName, int compression, Image** images, 
				   int nRows, int nCols, int nChannels);

int writeToPNG(char* szFileName, Image* image, int compression, int channels); 

// pre: g_camWidth,	g_camHeight and camera settings are appropriate
// post: sizeof(returned Image) = g_camWidth x g_camHeight
Image* getImageFromCamera();




#endif