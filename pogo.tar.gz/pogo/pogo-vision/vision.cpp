//
// POGO VISION
// Copyright (C) 2004 by the Institute for Systems Biology, Dave Orendorff. 
// All rights reserved.
// This code is distributed under the terms of the GNU Library General Public License.
// See COPYING for details.
//
// VISION.CPP
// Utilizes the functions written on other files to give the DLL
// a nice interface. Much input checking is done here. 
//

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <process.h>
#include <time.h>
#include <string.h>

#include "vision.h"
#include "globals.h"
#include "cameraimage.h"
#include "image.h"
#include "processimage.h"
#include "findspots.h"
#include "window.h"
#include "spotarea.h"
#include "anotherfindspots.h"



// time to wait (in ms) before an operation will fail, used when dealing
#define TIME_TO_WAIT 5000

// appends the string to the log file
int logEntry(char* szEntry);


// s_scene is actually just a vector of Images that has rows of a 3D matrix row*col*channel 
// concatinated one after another. 
static Image** s_scene = NULL;
static int s_nTileRows = -1;
static int s_nTileCols = -1;
static int s_nChannels = -1;	// note! valid values are 1-3


// temporary image used for speeding up the spotfinder
static Image* s_smallImage = NULL;

#ifndef USE_DAPPLE_ALG
static Image* s_smallOutline = NULL;
#endif 

////////////////////////////////////////////////////// MetaImage functions
//////////////////////////////////////////////////////////////////////////
/*
	The meta image is the composite image of all the photos that comprise 
	the entire slide.
	This is because the camera cannot take a picture of the entire slide.

	The thing to note is that internally, k minus 1 is how the data is stored for the channel.
*/

// acess the i, j, kth element from the s_scene vector (as if it were a 3D matrix)
#define ELEM(i, j, k) s_scene[i  * s_nChannels * s_nTileCols + j * s_nChannels + k]

/** sets up all of our information about the meta image
	doesn't work if there has already been one setup unless
	destroy is called.
*/
extern "C" DllExport long MY_CALLBACK SetupMetaImage(long nRows, long nCols, long nChannels){
	if (s_scene != NULL)
		return INTERNAL_DATA_NOT_CONSITANT;
	
	if (nRows < 0 || nCols < 0 || (nChannels != 1 && nChannels != 3))
		return BAD_ARGUMENT;

	s_scene = new Image*[nRows*nCols*nChannels];
	for (int i = 0; i < nRows*nCols*nChannels; i++) s_scene[i] = NULL;
		
	s_nTileRows = nRows;
	s_nTileCols = nCols;
	s_nChannels = nChannels;	

	return 0;
}

/**
	Puts the current image into the tile specified by these cordinates.
	Erases the current image that is in the 'buffer' and sets it to null.
	If there is already an image in this location then that image will be deleted first
*/
extern "C" DllExport long MY_CALLBACK InsertTile(long row, long col, long channel){
	if (s_scene == NULL)
		return INTERNAL_DATA_NOT_DEFINED;

	if (row < 0 || row > s_nTileRows || col < 0 || col > s_nTileCols || channel < 1 || channel > s_nChannels)
		return BAD_ARGUMENT;

// should this be an error?
//	if (g_spotsImg == NULL) return INTERNAL_DATA_NOT_DEFINED;

	if (ELEM(row, col, channel -1) != NULL)
		deleteImage(ELEM(row, col, channel - 1));
	
	if (g_spotsImg != NULL)
		ELEM(row, col, channel - 1) = deepCopy(g_spotsImg);

	return 0;
}

/**
	Dealocates all of the information in the meta image.
*/
extern "C" DllExport long MY_CALLBACK DestroyMetaImage(){
	if (s_scene == NULL) return INTERNAL_DATA_NOT_DEFINED;
	int length = s_nTileRows * s_nTileCols * s_nChannels;

	for (int i = 0; i < length; i++)
		deleteImage(s_scene[i]);

	delete [] s_scene;
	s_scene = NULL;
	return 0;
}


/** 
	saves the meta image to the specified file location
	note: this function deletes the file name string
*/
extern "C" DllExport long MY_CALLBACK SaveMetaImage(char* szFileName, long compression){
	if (szFileName == NULL || compression < 0) return BAD_ARGUMENT;
	if (s_scene == NULL) return INTERNAL_DATA_NOT_DEFINED;

	if (compression < 0 || compression > 9) return BAD_ARGUMENT;	// range of okay values for zlib

	szFileName = dublicateBackslashes(szFileName);

	// just save the images to a png, we are working under the following assumptions:
	/*
		1. the size of all images is the same. 
		2. the channels are all filled up. We can handle NULLs but the result will 
			not be pretty. 
		3. s_scene is arranged properly, aka: channal first expansion. 
		4. filename should probably end in .png
	*/

	int status = saveImages(szFileName, compression, s_scene, s_nTileRows, s_nTileCols, s_nChannels);
	delete [] szFileName;

	return status;
}


//////////////////////////////////////////////////////// Modifier functions 
///////////////////////////////////////////////////////////////////////////
extern "C" DllExport long MY_CALLBACK PhotographSpots(){
	if(g_camWidth < 0) return INTERNAL_DATA_NOT_DEFINED;

	if(CloseSpotWindow() != 0) return CAN_NOT_CLOSE_WINDOW;

	if(g_spotsImg != NULL) deleteImage(g_spotsImg);

	g_spotsImg = newImage(g_camWidth, g_camHeight, 
		new unsigned char[g_camWidth*g_camHeight]);

	return getGreyscale8BitCameraImage(g_spotsImg->_width, 
		g_spotsImg->_height, g_spotsImg->_data);
	
}


extern "C" DllExport long MY_CALLBACK PhotographBlank(){
	if(g_camWidth < 0) return INTERNAL_DATA_NOT_DEFINED;

	if(g_blankImg != NULL) deleteImage(g_blankImg);


	g_blankImg = newImage(g_camWidth, g_camHeight, 
		new unsigned char[g_blankImg->_width*g_blankImg->_height]);

	return getGreyscale8BitCameraImage(g_blankImg->_width, 
		g_blankImg->_height, g_blankImg->_data);
}


// g_spotsImg address will get changed.
extern "C" DllExport long MY_CALLBACK GaussianSmoothing(float sigma){
	if (sigma < 0) return BAD_ARGUMENT;
	if (sigma > 10) return BAD_ARGUMENT;
	if (g_spotsImg == NULL) return INTERNAL_DATA_NOT_DEFINED; 

	if (sigma == 0) sigma = 1.4f; 

	Image* temp = smoothGaussian(g_spotsImg, sigma);

	deleteImage(g_spotsImg);
	g_spotsImg = temp;

	return 0;
}

/**
	Apply gamma correction on the image. 
*/
extern "C" DllExport long MY_CALLBACK ApplyGamma(float gamma){
	if (gamma <= 0) return BAD_ARGUMENT;
	if (g_spotsImg == NULL) return INTERNAL_DATA_NOT_DEFINED;
	if(CloseSpotWindow() != 0) return CAN_NOT_CLOSE_WINDOW;

	gammaCorrect(g_spotsImg, gamma);
	return 0;
}

extern "C" DllExport long MY_CALLBACK FlipSpots(int flipHorizontal, int flipVertical){
	if (g_spotsImg == NULL)  return INTERNAL_DATA_NOT_DEFINED;
	if(CloseSpotWindow() != 0)  return CAN_NOT_CLOSE_WINDOW;

	flipImage(g_spotsImg, flipHorizontal != 0, flipVertical != 0);

	return 0;
}


/**
	Flattens the image according to the blank photograph. It is important to
	not have the image be previously gamma corrected or else the results will be messed up. 
*/
extern "C" DllExport long MY_CALLBACK ApplyFlattening(){
	if (g_blankImg == NULL || g_spotsImg == NULL)
		return INTERNAL_DATA_NOT_DEFINED;

	if (g_blankImg->_height != g_spotsImg->_height || g_blankImg->_width != g_spotsImg->_width)
		return INTERNAL_DATA_NOT_CONSITANT;

	if(CloseSpotWindow() != 0) return CAN_NOT_CLOSE_WINDOW;

	return flattenImage(g_spotsImg, g_blankImg);
}


//	Set up the region to be analyzed by the spotfinder
//	We're looking for the top left pixel, 
//
//  A photograph must be in the buffer for this to be called
//
//	Right now a 1x1 grid does not work
extern "C" DllExport long MY_CALLBACK SetRegion(long x1, long y1, long x2, long y2, long x3, long y3, long numSpotsX, long numSpotsY){
	if (g_spotsImg == NULL) return INTERNAL_DATA_NOT_DEFINED;

	// make sure these values are possible
	if(x1 < 0 || y1 < 0 || x3 < 0 || y3 < 0) return BAD_ARGUMENT;
	if(numSpotsX < 0 || numSpotsY < 0) return BAD_ARGUMENT;

	// a long pointer is not excepted as an int pointer.
	int nx1 = x1; int nx2 = x2;int nx3 = x3;
	int ny1 = y1; int ny2 = y2;int ny3 = y3;

	// pt1 does not change, and the new cordinates for pt3 are changed to reflect the affine transform
	if (nx2 > 0 && ny2 > 0)
		qualityAffine(g_spotsImg, nx1, ny1,  nx2,  ny2,  nx3, ny3);
	
	// TODO: if(g_grid != NULL) delete g_grid;

	// since we are given spot cordinates, and not grid cordinates, we want to 
	// figure out the extra spacing that is needed. 
	int xExtra = roundDbl((double)(x3 - x1) / ((double)(numSpotsX - 1)) / 2.0);

	int yExtra = roundDbl((double)(y3 - y1) / ((double)(numSpotsY - 1)) / 2.0);

	// guess vignette is a square, if we are only 1 thick or tall
	if (numSpotsX == 1 && numSpotsY > 1)
		xExtra = yExtra;
	if (numSpotsY == 1 && numSpotsX > 1)
		yExtra = xExtra; 

	g_grid = newGrid(y1 - yExtra, x1 - xExtra, y3 + yExtra, x3 + xExtra, numSpotsY, numSpotsX);

	// make sure these values are possible for our picture
	if (y3 + g_grid->_dy > g_spotsImg->_height || 
		x1 + g_grid->_dx > g_spotsImg->_width){
		delete g_grid;
		g_grid = NULL;
		return INTERNAL_DATA_NOT_CONSITANT;
	}


	// set up our temporary variables
	if (s_smallImage != NULL) deleteImage(s_smallImage);
		s_smallImage = newImage(g_grid->_dx, g_grid->_dy);

#ifndef USE_DAPPLE_ALG
	if (s_smallOutline != NULL) deleteImage(s_smallOutline);
		s_smallOutline = newImage(g_grid->_dx, g_grid->_dy);
#endif

	// non fatal errors
	if(g_grid->_dx - g_grid->_dy > 20 || g_grid->_dx > 60)
		return UNADVISED_RANGE_OF_DATA;
	if(g_grid->_dx < 5 ||  g_grid->_dy < 5)
		return UNADVISED_RANGE_OF_DATA;

	return 0;
}


// minRadius and maxRadius are in analysis inclusive
extern "C" DllExport long MY_CALLBACK SetSpotFinderParameters(long MinRadius, long MaxRadius, long ZeroTolerance){
	if (g_grid == NULL) return INTERNAL_DATA_NOT_DEFINED;
	if (ZeroTolerance < 0) return BAD_ARGUMENT;
	if (ZeroTolerance == 0) ZeroTolerance = 5; 


	if (MinRadius < 0 || MaxRadius < MinRadius || MaxRadius > g_grid->_dx)
		return BAD_ARGUMENT;



#ifdef USE_DAPPLE_ALG 
	int min, max;
	getSpotfinderRadii(min, max);
	if (min > 1)  killEngine();			// engine already started
#endif

	int radRange = MaxRadius - MinRadius;
	if (radRange < 0) return BAD_ARGUMENT;
	if (MinRadius < 1) return BAD_ARGUMENT;

		
#ifdef USE_DAPPLE_ALG
	startEngine(g_grid->_dx, g_grid->_dy, MinRadius,  MaxRadius,
		   0 /* radius fudge factor, ignore for now */,  1 /* SquashFactor */);
#else
	setupHough(g_grid->_dx, g_grid->_dy, MinRadius,  MaxRadius, ZeroTolerance);
#endif

	if (MaxRadius > g_grid->_dy)
		return UNADVISED_RANGE_OF_DATA;
	if (radRange > 30)
		return UNADVISED_RANGE_OF_DATA;

	return 0;
}


extern "C" DllExport long MY_CALLBACK GetFeatureInfo(long row, long col, long &dx, long &dy, long &area, long &quality){
	if (g_grid == NULL || g_spotsImg == NULL) return INTERNAL_DATA_NOT_DEFINED;
	
	int min, max;

#ifdef USE_DAPPLE_ALG
	getSpotfinderRadii(min, max);
#else
	getHoughRadii(min, max);
#endif

	if ( min < 1 || max < 1) return INTERNAL_DATA_NOT_DEFINED;	// have not started engine yet

	int x, y;	// top left corner of vignette
	getVignette(g_grid, row, col, x, y);

	if (x < 0) return BAD_ARGUMENT | UNKNOWN_ERROR;

	// can the new image be made from the larger?
	if (!subImage(g_spotsImg, s_smallImage, x, y)) return INTERNAL_DATA_NOT_CONSITANT;

	FltImage* negLap = negativeLaplacian(s_smallImage);

	int nIndex; // the pixel number that is the center of the spot
	int rad;

#ifdef USE_DAPPLE_ALG
	quality = (int)placeSpot(negLap, rad, nIndex);
#else
	zeroCrossings(negLap, s_smallOutline);
	quality = houghCircle(s_smallOutline, nIndex, rad); 
#endif

	dx = nIndex%s_smallImage->_width - g_grid->_dx/2;
	dy = nIndex/s_smallImage->_width - g_grid->_dy/2;

#ifdef NOT_USE_ADV_AREA
	area = roundFltToInt(rad * rad * 3.141);
#else
	area = spotArea(negLap, nIndex%negLap->_width, nIndex/negLap->_width, rad);
#endif

	if (area < rad * rad)	// hopefully a rare occuriance, but could happen
		area = roundFltToInt(rad * rad * 3.14f);

	deleteFltImage(negLap);

	return 0;
}


///////////////// visualization functions
/////////////////////////////////////////

extern "C" DllExport long MY_CALLBACK ShowSpots(long shrinkFactor){	
	if (g_spotsImg == NULL) return INTERNAL_DATA_NOT_DEFINED;
	
	int status = CloseSpotWindow();
	if (status != 0)  return status;

	// there may be a potential for a div(0) with a nonusefully-large shrink factor
	if (shrinkFactor < 1 || shrinkFactor > 1000) return BAD_ARGUMENT;

	CloseSpotWindow();
	setShrinkFactor(shrinkFactor);
	_beginthread(showImage, 0, (void*)g_spotsImg);
	return 0;
}

// This function basically just closes the window, if it's open.
// we do not want to lock up the host program, so we have a timer
extern "C" DllExport long MY_CALLBACK CloseSpotWindow(){

	// window open even?
	if (!g_windowOpen){
		return 0;
	}

	// windows open
	int elapsed = 0;

	time_t t = clock();

	// remember, the window is on a thread so we need to wait for it.
	killWindow();
	while (g_windowOpen && elapsed < TIME_TO_WAIT){ elapsed = clock() - t;}
	
	if (elapsed >= TIME_TO_WAIT && g_windowOpen)
		return CAN_NOT_CLOSE_WINDOW;
	return 0;
}

extern "C" DllExport long MY_CALLBACK  GridShown(long shown){
	isGridShown(shown != 0);
	return 0;
}


/**
	Gets the cordinate box that the user clicked into existance. For this function to work
	properly a new window should not have been created before *this one.
*/
extern "C" DllExport long MY_CALLBACK GetUserCreatedRectangle(long &x1, long &y1, long &x2, long &y2, long &x3, long &y3){
	int nx1, nx2, nx3, ny1, ny2, ny3;
	getEdges(nx1, ny1, nx2, ny2, nx3, ny3);
	x1 = nx1; x2 = nx2; x3 = nx3; y1 = ny1; y2 = ny2; y3 = ny3;
	return 0;
}


/////////////////////////// DEBUG MODE
// TODO: derive consistancy in #define's s.t. this is not a problem
#ifdef DEBUG_MODE
#endif
extern "C" DllExport long MY_CALLBACK PhotographVirtualSpots(){
	if (g_spotsImg != NULL) deleteImage(g_spotsImg);

	g_spotsImg = readFromPNG("virtualspots.png");

	return g_spotsImg != NULL ? 0 : FILE_IO_ERROR;
}

extern "C" DllExport long MY_CALLBACK PhotographVirtualBlank(){
	if (g_blankImg != NULL) deleteImage(g_blankImg);

	g_blankImg = readFromPNG("virtualblank.png");

	return g_blankImg != NULL ? 0 : FILE_IO_ERROR;
}

int logEntry(char* szEntry){
	// appends to file
	if (szEntry == NULL) return BAD_ARGUMENT;
	FILE *fp = fopen("log.txt", "a+");

    if (!fp)
       return FILE_IO_ERROR;

	fprintf(fp, "\n%s", szEntry);

	fclose(fp);
	return 0;
}