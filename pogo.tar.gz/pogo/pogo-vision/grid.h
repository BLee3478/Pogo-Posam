//
// POGO VISION
// Copyright (C) 2004 by the Institute for Systems Biology, Dave Orendorff. 
// All rights reserved.
// This code is distributed under the terms of the GNU Library General Public License.
// See COPYING for details.
//
// GRID.H
//	Interface. Deals with the grid-geometry aspect of the image.
//	
//	Pixels are assumed to be in the form (x, y) where (0, 0) is the
//		top-left and (Amax, Bmax) is the lower-right of an image of Amax 
//		width and Bmax height. 
//
//	Vignettes are represented in row/collumn notation, starting at 0. 
//
// There is an unregulated rule stating that a Grid's data should 
// not be modified outside of these functions. 
//



#ifndef _GRID_H_
#define _GRID_H_



struct Grid{
	int _top, _left, _bottom, _right;	// pixel boundry cordinates

	int _rows, _cols;	// how many rows, cols

	int _dx, _dy;		// distance between ajacent vignettes
};


// nRows, nCols designate the number of spots.
Grid* newGrid(int top, int left, int bottom, int right, int nRows, int nCols);

/* 
	Returns the exact top left pixel of specified vignette into (x, y)
		pre: grid is initiallized; row, col > 0 AND inside(grid)
		post: (x, y) is top left pixels of this vignette
*/
void getVignette(Grid* grid, int row, int col, int &x, int &y);


#endif 