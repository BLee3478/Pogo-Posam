// another set of operations to act as a spotfinder
// based off of houghs transform


//
// GamePlan: 
//	1. Find edges - 2nd order detection, based on LoG edge detection
//
//	2. find a circle by mapping the edge pixels into hough space (Hough's algorthm)
//		- see houghCircle(...) for more on the algorithm
//

#include <stdio.h>
#include <assert.h>
#include <math.h>

#include "anotherfindspots.h"
#include "image.h"
#include "processimage.h"
#include "window.h"



#define FILLED 10
#define LINEVAL 0xFF

static Image* s_houghSpace = NULL; // map of the hough space of our edges 
static int *s_circumferences = NULL; // sizeof(maxRadius)
static int s_minRadius, s_maxRadius; 
static int s_zeroTol = 5;

static float* s_convolution = NULL;
static int s_convLength = 0;	// sizeof(s_convolution), should be odd

void zeroCrossings(FltImage* conv, Image* bOut);

// calculates the exact circumference when a circle of this radius is drawn 
// onto a discrete region. In pixels. 
int circumference(int radius){
		int dx = 0;
	int dy = radius; 
	int decision = 3 - (2 * radius); 

	int circumference = 0; 
	
	// start from the very top and calc the first PI / 4 going right
	while (dx <= dy)
	{		
		circumference++;
		if (decision < 0) 
			decision += (4 * dx) + 6;
		else{
			decision += 4 * (dx - dy) + 10;
			dy--;
		}
		dx++;
	}
	return 8 * circumference;
}

// draws a circle outline onto the image, based on bresenham's algorthm, center at <x, y>
// just adds the pixels that fall onto this cirlce with fill
// time: O(c) * circumference
void bresenhamCircle(Image* image, int x, int y, int radius, unsigned char fill){
	int dx = 0;
	int dy = radius; 
	int decision = 3 - (2 * radius); 

	// temporary variables
	int tx, ty; 
	
	// start from the very top and calc the first PI / 4 going right
	while (dx <= dy)
	{
		// add the 8 circle pixels onto the octants
		tx = x + dx; ty = y + dy;
		if (inBounds(image, tx, ty)) image->_data[image->_width*ty + tx] += fill;
		
		tx = x + dx; ty = y - dy;
		if (inBounds(image, tx, ty)) image->_data[image->_width*ty + tx] += fill;
		
		tx = x - dx; ty = y + dy;
		if (inBounds(image, tx, ty)) image->_data[image->_width*ty + tx] += fill;

		tx = x - dx; ty = y - dy;
		if (inBounds(image, tx, ty)) image->_data[image->_width*ty + tx] += fill;

		tx = x + dy; ty = y + dx;
		if (inBounds(image, tx, ty)) image->_data[image->_width*ty + tx] += fill;

		tx = x + dy; ty = y - dx;
		if (inBounds(image, tx, ty)) image->_data[image->_width*ty + tx] += fill;

		tx = x - dy; ty = y + dx;
		if (inBounds(image, tx, ty)) image->_data[image->_width*ty + tx] += fill;

		tx = x - dy; ty = y - dx;
		if (inBounds(image, tx, ty)) image->_data[image->_width*ty + tx] += fill;
		
		if (decision < 0) 
			decision += (4 * dx) + 6;
		else{
			decision += 4 * (dx - dy) + 10;
			dy--;
		}
		dx++;
	}
}



// assumes product is cleared out, edges has the outline of our circle
// draws |number of pixels in edges| circles onto product
// Time: O(n) * circumference
void mapHoughCircleSpace(Image* edges, Image* product, int radius){
	for (int x = 0; x < edges->_width; x++)
		for (int y = 0; y < edges->_height; y++){
			if (getPixel(edges, x, y) != 0) bresenhamCircle(product, x, y, radius, FILLED); 
		}
}


// gets the index of the greatest valued pixel in the image
int greatestPixel(Image* image){
	int length = image->_height * image->_width;
	unsigned char bestVal = 0;
	int bestIndex = 0; 

	for (int i = 0; i < length; i++){
		if (image->_data[i] > bestVal){
			bestVal =  image->_data[i];
			bestIndex = i; 
		}
	}

	return bestIndex;
}

// makes the image into a blank
void clearImage(Image* image){
	int length = image->_height * image->_width;
	for (int i = 0; i < length; i++)
		image->_data[i] = 0;
}

// the range of radii that we are searching through
void getHoughRadii(int &min, int &max){
	min = s_minRadius;
	max = s_maxRadius;
}

// 
// pre: width, height, minRad, maxRad are correct
// width, height are the exact size of the image to be 
// analyzed. (use logic if you don't know what correct means)
void setupHough(int width, int height, int minRad, int maxRad, int zeroTol){

	if (s_circumferences != NULL)
		delete [] s_circumferences;

	s_minRadius = minRad;
	s_maxRadius	= maxRad;
	s_zeroTol = zeroTol;	// zero tolerance

	s_circumferences = new int [maxRad + 1];
	s_circumferences[0] = 0; 

	for (int rad = 1; rad <= maxRad; rad++)
		s_circumferences[rad] = circumference(rad);

	if (s_houghSpace == NULL)
		s_houghSpace = newImage(width, height);
	else if(s_houghSpace->_width != width || height != height){
		deleteImage(s_houghSpace);
		s_houghSpace = newImage(width, height);
	}
}


// return the 'quality', size and location of the circle. 
// edges is a binary image representing the edges of our circle
// and the globalIndex, radius values are the most likely location and size for this circle
// pre: setupHough has been called, so everything is in order; edges != 0
// 
// WHAT IT DOES:
//    for every pixel in the edges image, a circle is drawn (added) onto the temporary image.
//			- the center of this circle is at the location of the edge
//
//	  once all edge pixels have been represented as circle on the temporary image, the pixel of greatest 
//		magnitude is considered the most likely canidate for a circle.
//
//	  this cycles through all of the possible radii, finding the global maximum intercept
//	  the returned quality is the percentage (0-100) of actual outline that follows the possible 
//	  outline. 
//
//		* note that smaller spots will appear to have a higher quality. 
//	  
int houghCircle(Image* edges, int &globalIndex, int &bestRadius){
	assert(s_circumferences != NULL);

	// best values
	globalIndex = 0;
	bestRadius = 1;
	int globalValue = 0; 

	if (s_houghSpace == NULL) return 0;	// need to setup everything first
	
	int imageLength = edges->_height * edges->_width;

	for (int rad = s_minRadius; rad <= s_maxRadius; rad++){
		clearImage(s_houghSpace);
		mapHoughCircleSpace(edges, s_houghSpace, rad); 
		int index = greatestPixel(s_houghSpace);		// largest index in the image

//		if (s_houghSpace->_data[index] * s_circumferences[bestRadius] > globalValue * s_circumferences[rad] ){	// this is looking at the percentages of the		
													// circle outlines that are filled without no division
		// suprisingly, it seems to work better if we just go off of raw circle intercepts
		if (s_houghSpace->_data[index] > globalValue  ){
													
			bestRadius = rad;
			globalIndex = index;
			globalValue = s_houghSpace->_data[index];
		}
	}

	globalValue *= 100;
	return globalValue / bestRadius;	// the percentage of the circle that was filled * 100
}


// Whenever pixels in conv go from positive to negative (within tolerance) this 
// indicates that there is a line present in the picture at this point. These
// lines are then mapped onto bOut. 
//
// Note: it is assumed that conv is the second derivitive of a function. 
void zeroCrossings(FltImage* conv, Image* bOut){
	clearImage(bOut);
	int mr = s_convLength;
	int i, j, p, q;
	

	for (i=1;i < conv->_width - 1;i++)
		{
		for (j=1;j < conv->_height - 1;j++)
			{
			setPixel(bOut, i, j, 0);
			if (getFltPixel(conv, i, j) > s_zeroTol)	// implied (conv[i][j] < -s_zeroTol), case covered (?)
				{
				for (p=-1;p<=1;p++)
					{
					for (q=-1;q<=1;q++)
						{
						if (getFltPixel(conv, i+p, j+q) < -s_zeroTol)
							{
								setPixel(bOut, i, j, LINEVAL);
							}
						}
					}
				}
			else if ((fabs)(getFltPixel(conv, i, j)) < s_zeroTol)
				{// is there a positive neibor on one side and a negative on the exact opposite?
				if (((getFltPixel(conv, i+1, j) > s_zeroTol) && (getFltPixel(conv, i-1, j) < -s_zeroTol)) || ((getFltPixel(conv, i+1, j) < -s_zeroTol) && (getFltPixel(conv, i-1, j) > s_zeroTol)))
					{
					setPixel(bOut, i, j, LINEVAL);
					}
				else if (((getFltPixel(conv, i, j+1) > s_zeroTol) && (getFltPixel(conv, i, j-1) < -s_zeroTol)) || ((getFltPixel(conv, i, j+1) < -s_zeroTol) && (getFltPixel(conv, i, j-1) > s_zeroTol)))
					{
					setPixel(bOut, i, j, LINEVAL);
					}
				else if (((getFltPixel(conv, i+1, j+1) > s_zeroTol) && (getFltPixel(conv, i-1, j-1) < -s_zeroTol)) || ((getFltPixel(conv, i+1, j+1) < -s_zeroTol) && (getFltPixel(conv, i-1, j-1) > s_zeroTol)))
					{
					setPixel(bOut, i, j, LINEVAL);
					}
				else if (((getFltPixel(conv, i+1, j-1) > s_zeroTol) && (getFltPixel(conv, i-1, j+1) < -s_zeroTol)) || ((getFltPixel(conv, i+1, j-1) < -s_zeroTol) && (getFltPixel(conv, i-1, j+1) > s_zeroTol)))
					{
					setPixel(bOut, i, j, LINEVAL);
					}
				}
			}
		}
}



//////////////////////////////////////////////////////////
///////////////////////////////////////////////// NOT USED


/** calulates the 2nd derivitive of the gausian distribution on a 1D array, centered in the middle.
   formula:
			d = distance from center, s = sigma
			Gaussian = e^(-d^2 / (2 * s^2))
			Gaussian`` = ((d^2 - s^2) / s ^ 4) * e^(-d^2 / (2 * s^2))
*/
void calculateConvolution(float sigma){
	assert(sigma > 0);
	if (s_convolution != NULL) delete [] s_convolution;

	s_convLength = int(sigma * 3 * 2) + 1;	// 3 s.d., always odd 
	s_convolution = new float[s_convLength];

	int convOver2 = s_convLength / 2;

	float sigma2 = sigma * sigma; 
	float oneOverS4 = sigma2 * sigma2; oneOverS4 = 1 / oneOverS4;

	s_convolution[convOver2] =  -sigma2 * oneOverS4; //((d^2 - s^2) / s ^ 4)

	for (int i = 1; i <= convOver2; i++){
		// could be sped up, but it shouldn't matter too much
		s_convolution[convOver2 - i] = float(((i * i - sigma2) * oneOverS4) * exp(-(i * i) / (2.0f * sigma2)));
//		s_convolution[convOver2 - i] = (2 - i / sigma2) * exp(-(i * i) / (2 * sigma2));	// 1st derivitive
		s_convolution[convOver2 + i] = s_convolution[convOver2 - i];	// semetric around middle
	}	
}


// uses the static convolution array on this array
void convolve1D(unsigned char *array, float* convolution, int length){

	int convOver2 = s_convLength / 2;

	for (int i = 0; i < length; i++){
		int offset = MIN(i, convOver2); offset *= -1;
		int limit = MIN(convOver2, length - i - 1);
		convolution[i] = 0; //array[i];
		for (; offset <= limit; offset++){
			convolution[i] += s_convolution[offset + convOver2] * (float)array[i + offset];
		}
	}
}

// convolves the array
// ~in place (has a mini buffer that is the old left hand side values)
void convolve1DFlt(float *source, float *result, int length){

	int convOver2 = s_convLength / 2;

	for (int i = 0; i < length; i++){

		int offset = MIN(i, convOver2); offset *= -1;
		int limit = MIN(convOver2, length - i - 1);
		result[i] = 0;

		for (; offset <= limit; offset++){
			result[i] += s_convolution[offset + convOver2] * (float)source[i + offset];
		}
	}

}



// NOTE: I should be able to do the LoG in one step, but i was getting inoperable results.
//		Instead, i do them in two steps, these functions are in processimage.h
//
// for outlining, LoG operation. 
// gameplan: 
//  -smooth image using a gausian convolution
//  -find 2nd derivitive using laplacian
// 
// note: we can find a convolution of these 2 convolutions
// also, we can do the x, y axis seperatly
// sigma = standard deviation 
//
// post: outline is true at points of zero crossing (within epsilon)
void LaplacianOfGausian(Image* origional, Image *outline, float sigma){
	calculateConvolution(sigma);
	clearImage(outline);
	int length = origional->_width * origional->_height;

	unsigned char* data = origional->_data;

	FltImage* convolution = newFltImage(origional->_width, origional->_height, new float[length]);
	int x, y, index;
	float *fdata = convolution->_data; 

	for (y = 0; y < origional->_height; y++){
		
		// convolve in the x direction
		index = y * origional->_width;
		convolve1D(&data[index], &fdata[index], origional->_width);
	}
	
	calculateConvolution(sigma);

	float *result = new float[origional->_height];
	float *source = new float[origional->_height];
	for (x = 0; x < origional->_width; x++){

		// copy an entire column from the x convolution into source
		for (y = 0; y < convolution->_height; y++){
			source[y] = getFltPixel(convolution, x, y); 
		}

		convolve1DFlt(source, result, origional->_height);

		// copy it back into our final image
		for (y = 0; y < origional->_height; y++)
			setFltPixel(convolution, x, y, result[y]);

	}

	delete [] result; 
	delete [] source; 

	zeroCrossings(convolution, outline);	// find the outline 

	delete [] convolution->_data;
	delete convolution; 
}

