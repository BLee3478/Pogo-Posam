//
// POGO VISION
// Copyright (C) 2004 by the Institute for Systems Biology, Dave Orendorff. 
// All rights reserved.
// This code is distributed under the terms of the GNU Library General Public License.
// See COPYING for details.
//
// CAMERAIMAGE.H
// Interface: gets a photo from the IEEE camera.

#ifndef __GETCAMERAIMAGE_H
#define __GETCAMERAIMAGE_H


// pre: sizeof(data) = width*height; 
// post: data contains the raw bytes of the picture taken if the camera
//		 could be connected. 
int getGreyscale8BitCameraImage(int width, int height, unsigned char* data); 



#endif