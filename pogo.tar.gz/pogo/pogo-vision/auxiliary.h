//
// POGO VISION
// Copyright (C) 2004 by the Institute for Systems Biology, Dave Orendorff. 
// All rights reserved.
// This code is distributed under the terms of the GNU Library General Public License.
// See COPYING for details.
//
// AUXILIARY.H
// Interface to various functions and macros used throughout the program.


#ifndef _AUXILIARY_H_
#define _AUXILIARY_H_

#include <math.h>


#define MIN(a,b) (a < b) ? a : b

#define MAX(a,b) (a > b) ? a : b

#define SWAP(a, b) a^= b; b ^= a; a ^= b;

//
// Compute the next power of 2 greater than a value v.
//
inline unsigned int nextpow2(unsigned int v)
{
  int p; for (p = 0; v > 0; v >>= 1, p++); return (1U << p);
}



__inline int roundDbl (double flt) 
{	int intgr;

	_asm{	
		fld flt
		fistp intgr
	} ;
		
	return intgr ;
} 


inline int roundFltToInt(float flt)
{	
	int intgr;
	// much faster, (int) casting is expensive
	_asm{	
		fld flt
		fistp intgr
	} ;	
	return intgr ;
}

// exchange contents
inline void swap(unsigned char &a, unsigned char &b){
	a ^= b;
	b ^= a;
	a ^= b;
}

// reverses this array. 
void flipArray(unsigned char *array, int length);

// exchanges the contents of a1 and a2
void switchArrays(unsigned char *a1, unsigned char *a2, int length);

/** 
	For every occuriance of the '\' charecter, another '\' is added after it.
	This is usefull when dealing with file locations where '\' is an escape 
	character.
	pre: sz is a null terminated string (0 length is okay)
	post: old sz memory is taken care of, a new sz is returned. 
*/
char* dublicateBackslashes(char* sz);

void pixSort(unsigned char *pixels, int npixels);


#endif 