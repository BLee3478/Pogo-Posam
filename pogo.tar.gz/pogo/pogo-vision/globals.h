//
// POGO VISION
// Copyright (C) 2004 by the Institute for Systems Biology, Dave Orendorff. 
// All rights reserved.
// This code is distributed under the terms of the GNU Library General Public License.
// See COPYING for details.
//
// GLOBALS.H
// Defines global variables and error messages. 
//

#ifndef _GLOBALS_H_
#define _GLOBALS_H_

#include "image.h"
#include "grid.h"

/** The error messages that will be passed to the caller. */
#define BAD_ARGUMENT					0x0001
#define INTERNAL_DATA_NOT_DEFINED		0x0002
#define INTERNAL_DATA_NOT_CONSITANT		0x0004

#define CAN_NOT_CLOSE_WINDOW			0x0010

#define UNADVISED_RANGE_OF_DATA			0x0100

#define FILE_IO_ERROR					0x1000
#define CAMERA_ERROR					0x2000
#define CAMERA_NOT_FOUND				0x4000
#define UNKNOWN_ERROR					0x8000


// GLOBAL VARIABLES

extern Image* g_spotsImg;	// THE global image
extern Image* g_blankImg;	// the image used for flattening

extern Grid* g_grid;		// represents the geometry set by the caller program

extern int g_camWidth;		
extern int g_camHeight;		


/** variable having to do with our window. */

// we need to know if there is a window open in another thread. 							
extern bool g_windowOpen;			 


#endif